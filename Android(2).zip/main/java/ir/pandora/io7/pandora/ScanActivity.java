package ir.pandora.io7.pandora;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.google.zxing.Result;

import java.io.FileOutputStream;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ScanActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);




        //Remove title bar
        //  this.requestWindowFeature(Window.FEATURE_NO_TITLE);

    }
    private ZXingScannerView mScannerView;

    public void QrScanner(View view){



        //------------------------ test ------------------
/*
        setPADB("201706010343");
PagerActivity.checkScanRes();

       // super.onBackPressed();
finish();
*/
        //-----------------------------------------------




        //FrameLayout frm1 = (FrameLayout) findViewById(R.id.frm1);
        // Button scbt = (Button) findViewById(R.id.scbtn);

        mScannerView = new ZXingScannerView(this);   // Programmatically initialize the scanner view
        setContentView(mScannerView);

        // frm1.addView(mScannerView);

        mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        mScannerView.startCamera();         // Start camera

    }

    public int prevLen=0;
    public int equelCount=0;

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
/*
        Log.e("handler", rawResult.getText()); // Prints scan results
        Log.e("handler", rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode)

        // show the scanner result into dialog box.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Scan Result");
        builder.setMessage(rawResult.getText());
        AlertDialog alert1 = builder.create();
        alert1.show();
*/

        //  setContentView(R.layout.activity_main);
        mScannerView.stopCamera();
        //ProgressBar v = (ProgressBar) findViewById(R.id.pb);
        //v.setX(0);
        //wv1=(WebView)findViewById(R.id.webView);
        //wv1.loadUrl("javascript:set_Barcode('"+rawResult.getText()+"')");
        //  this.urx1="http://pandora.ir/mobile/Gallery.aspx?q="+rawResult.getText();
        //this.start1();

        // If you would like to resume scanning, call this method below:
        // mScannerView.resumeCameraPreview(this);

        String res=rawResult.getText();
        //  this.urx1="http://pandora.ir/mobile/Gallery.aspx?q="+rawResult.getText();
        //this.start1();
        //Toast.makeText(this,"scan:: "+res, Toast.LENGTH_LONG).show();



        // App mApp = ((App)getApplicationContext());
        //mApp.set_cuShoCod(res);

        //  setPADB(res);


        //super.onBackPressed();



       /* setPADB(res);
        PagerActivity.checkScanRes();

        super.onBackPressed();
        finish();
*/
        if(res.length()==12) {
            setPADB(res);
            MainActivity.checkScanRes();

            super.onBackPressed();
            finish();
        }else{

            int culen=res.length();
            if((culen>0)){
                if((culen!=prevLen)){
                    prevLen=culen;
                    equelCount=0;
                }else {
                    equelCount++;
                }
                if(equelCount>=300){
                    super.onBackPressed();
                    finish();
                }
            }

            // Toast.makeText(this,"scan:: "+res, Toast.LENGTH_LONG).show();
        }


       /* Intent intent = new Intent(this,PagerActivity.class);//IO7Activity.class);// PagerActivity.class);// MainActivity.class);
        startActivity(intent);
        */
//finish();





        //getApplication().get_cuShoCod()

        // ((dieApp)this.getApplication()).get_cuShoCod();
        //()
       /* (this.getApplication()).set
        // set
        ((pandorair) this.getApplication()).setSomeVariable("foo");

// get
        String s = ((MyApplication) this.getApplication()).getSomeVariable();
*/
    }

    public void setPADB(String prm){

        String filename = "scanRes";
        String string = prm;//"BCC:"+prm+";";
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(string.getBytes());
            outputStream.close();
            //Toast.makeText(this,"write 2 file OK:: "+ string, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // Toast.makeText(this,"write 2 file ERR:: "+ prm, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

   /* @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {



        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    ////Toast.makeText(this, "key down event BACK.....", Toast.LENGTH_LONG).show();
                    //goBack();
                    super.onBackPressed();
                    return true;
            }

        }
        return super.onKeyDown(keyCode, event);
    }*/



}
