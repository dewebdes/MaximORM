package ir.pandora.io7.pandora;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.customtabs.CustomTabsIntent;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.iid.InstanceID;
import com.wang.avi.AVLoadingIndicatorView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private WebView NWB1;
    private WebView NWB0;
    public boolean themLoaded=false;
    public boolean serverLoaded=false;
    public boolean haveInternetErr=false;
    public boolean mustReload=false;
Context cox;
    public static View dieViewStatic;
public static ImageView ieImg;

public String devToken="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //View v = inflater.inflate(R.layout.activity_first_fragment, container, false);
        thisActivity=this;

        ieImg = (ImageView) findViewById(R.id.imageViewIE);
/*
        final Handler h0 = new Handler();
        h0.postDelayed(new Runnable() {

                          @Override
                          public void run() {

                              boolean haveInternet=false;// isInternetAvailable();

                              haveInternet=isNetworkAvailable(getBaseContext());
                              if(haveInternet==false){
                                  showInternetEr();
                              }
                              h0.postDelayed(this, 100);
                          }
                      }
                , 100);

*/



        //dieViewStatic=this;

        /*
cox=this;
        Button buttonOne = (Button) findViewById(R.id.button1);
        buttonOne.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                //Do stuff here
                openCustomTab("http://yahoo.com");

            }
        });
*/



        readBaseDB();

        final Handler h = new Handler();
        h.postDelayed(new Runnable() {
            private long time = 0;

            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void run() {


                hideWait();

                NWB1 = (WebView) findViewById(R.id.NWB1);
                NWB1.getSettings().setJavaScriptEnabled(true);
                NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(getBaseContext()), "app");
                NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                } else {
                    NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                }
                NWB1.setWebViewClient(new MyBrowser());
                NWB1.getSettings().setLoadsImagesAutomatically(true);
                NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                NWB1.getSettings().setAppCacheEnabled(false);
                NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
                NWB1.getSettings().setJavaScriptEnabled(true);
                NWB1.getSettings().setDomStorageEnabled(true);
                NWB1.getSettings().setUseWideViewPort(true);
                NWB1.setWebChromeClient(new WebChromeClient());
                NWB1.setScrollbarFadingEnabled(true);
                NWB1.clearCache(true);
                NWB1.setVerticalScrollBarEnabled(false);
                NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
                String furl = "http://fashionshop.maxim.shop/pandora.html?";


                NWB1.setHorizontalScrollBarEnabled(false);


                NWB1.loadUrl(furl);


                //  Toast.makeText(getContext(), "furl:: "+furl, Toast.LENGTH_LONG).show();
                NWB1.setWebViewClient(new WebViewClient() {
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        if(onIEER==false) {
                            onIEER = true;
                            NWB1.loadUrl("file:///android_asset/myerrorpage.html");
                            //ImageView img2 = (ImageView) findViewById(R.id.imageView2);
                            //img2.setVisibility(view.VISIBLE);
                            ieImg.setVisibility(view.VISIBLE);

                        }
                    }
                });
                /*NWB1.setWebViewClient(new WebViewClient() {

                    @Override
                    public void onLoadResource(WebView view, String url) {

                        //Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
                    }
                });
*/

    //----------------------------------------------------------------

                NWB0 = (WebView) findViewById(R.id.NWB0);
                NWB0.getSettings().setJavaScriptEnabled(true);
                NWB0.addJavascriptInterface(new WebViewJavaScriptInterface(getBaseContext()), "app");
                NWB0.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    NWB0.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                } else {
                    NWB0.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                }
                NWB0.setWebViewClient(new MyBrowser());
                NWB0.getSettings().setLoadsImagesAutomatically(true);
                NWB0.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                NWB0.getSettings().setAppCacheEnabled(false);
                NWB0.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
                NWB0.getSettings().setJavaScriptEnabled(true);
                NWB0.getSettings().setDomStorageEnabled(true);
                NWB0.getSettings().setUseWideViewPort(true);
                NWB0.setWebChromeClient(new WebChromeClient());
                NWB0.setScrollbarFadingEnabled(true);
                NWB0.clearCache(true);
                NWB0.setVerticalScrollBarEnabled(false);
                NWB0.getSettings().setAllowUniversalAccessFromFileURLs(true);
                String furl2 = "http://pandora.ir/mobile/connector/?bsk="+basketad;


                NWB0.setHorizontalScrollBarEnabled(false);


                NWB0.loadUrl(furl2);


                //  Toast.makeText(getContext(), "furl:: "+furl, Toast.LENGTH_LONG).show();

                NWB0.setWebViewClient(new WebViewClient() {

                    @Override
                    public void onLoadResource(WebView view, String url) {

                        //Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
                    }
                });


                //----------------------------------------------------



                /*
                boolean haveInternet=false;// isInternetAvailable();

                haveInternet=isNetworkAvailable(getBaseContext());
                if(haveInternet==false){
                    showInternetEr();
                }
*/

                //h.postDelayed(this, 100);
                final Handler h2 = new Handler();
                h2.postDelayed(new Runnable() {
                    private long time = 0;

                    @Override
                    public void run() {

                        final ImageView imageView = (ImageView) findViewById(R.id.imageView);
                        Animation myFadeInAnimation = AnimationUtils.loadAnimation(getBaseContext(), R.anim.fadein);
                        imageView.startAnimation(myFadeInAnimation); //Set animation to your ImageView

                        imageView.animate().scaleX(2).scaleY(2).alpha(0).setDuration(1000);




                        final Handler h3 = new Handler();
                        h3.postDelayed(new Runnable() {
                            private long time = 0;

                            @Override
                            public void run() {

                                imageView.setVisibility(View.GONE);
                                showWait();
                                NWB1.setVisibility(View.VISIBLE);

                                //Animation fstshow = AnimationUtils.loadAnimation(getBaseContext(), R.anim.fastshow);
                                //NWB1.startAnimation(fstshow); //Set animation to your ImageView


                            }
                        }, 1000);




                    }
                }, 3000);
            }
        }, 3000);
    }

    public void WifiRetry(View view){

       // ImageView img2 = (ImageView) findViewById(R.id.imageViewIE);
        ieImg.setVisibility(view.INVISIBLE);//.setVisibility(view.GONE);
        onIEER=false;
        String furl = "http://fashionshop.maxim.shop/pandora.html?";
        NWB1.loadUrl(furl);
    }

    public String lastSchem="";

    public boolean isNetworkAvailable(Context context) {
        final ConnectivityManager connectivityManager = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE));
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public boolean onIEER=false;
    @Override
    public void onStart() {
        super.onStart();

        if (true) {

            final Handler h = new Handler();
            h.postDelayed(new Runnable() {
                              private long time = 0;

                              @Override
                              public void run() {

                                /*  boolean haveInternet=false;// isInternetAvailable();

                                  haveInternet=isNetworkAvailable(getBaseContext());
                                  if(haveInternet==false){
                                      showInternetEr();
                                  }
*/

                                  if (true) {

                                      if(haveInternetErr==true){
                                          haveInternetErr=false;
                                          if(onIEER==false) {
                                              onIEER=true;
                                              NWB1.loadUrl("file:///android_asset/myerrorpage.html");
                                             // ImageView img2 = (ImageView) findViewById(R.id.imageViewIE);
                                              ieImg.setVisibility(View.VISIBLE);//.setVisibility(View.VISIBLE);
                                          }
                                      }

                                      if(mustReload==true){
                                          mustReload=false;
                                          String furl0 = "http://fashionshop.maxim.shop/pandora.html?";
                                          NWB1.loadUrl(furl0);
                                      }

                                      boolean canRun = themLoaded;

                                      if (canRun == true) {

                                          String dieCmd = getCmd1();
                                          if (!isnullVal(dieCmd)) {
                                              exeJS(dieCmd);
                                          }
                                      }
                                      canRun = serverLoaded;

                                      if (canRun == true) {

                                          String dieCmd = getCmd0();
                                          if (!isnullVal(dieCmd)) {
                                              exeJS0(dieCmd);
                                          }
                                      }

                                      if(isnullVal(lastSchem)==false){
                                          try {
                                              String dieSchem = lastSchem;
                                              lastSchem = "";
                                              Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(dieSchem));
                                              startActivity(browserIntent);
                                              //Toast.makeText(getBaseContext(), "open:: "+dieSchem, Toast.LENGTH_LONG).show();
                                          } finally {
                                              lastSchem = "";
                                          }
                                      }

                                  }
                                  h.postDelayed(this, 100);
                              }
                          }
                    , 100);
        }

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {



        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    //Toast.makeText(this, "key down event BACK.....", Toast.LENGTH_LONG).show();
                    //goBack();
                    //String exec2 = "runGoBack();";
                    //addCmd1(exec2);
                    //Toast.makeText(thisActivity , "scan result:: " + res, Toast.LENGTH_LONG).show();
                    exeJSstatic("javascript:runGoBack();");
                    return true;
            }

        }
        return super.onKeyDown(keyCode, event);
    }


    public void exeJS(String exec){
        NWB1.loadUrl(exec);
    }
    public void exeJS0(String exec){
        NWB0.loadUrl(exec);
    }

   //----------------------------------------------------

    public boolean isnullVal(String str){
        boolean ret=true;
        if(str != null && !str.isEmpty()) { ret=false; }
        return ret;
    }
    public static String[] cmd0Ar=new String[100];
    public static int lastCmd0Indx=0;

    public void addCmd0(String cmd){
        //Toast.makeText(this, "before add cmd 0::"+cmd, Toast.LENGTH_LONG).show();
        if(!isnullVal(cmd)) {
            if (Arrays.asList(cmd0Ar).contains(cmd)) {
                // is valid
            } else {
                cmd0Ar[lastCmd0Indx] = cmd;
                lastCmd0Indx++;
                // Toast.makeText(this, "add cmd 0::"+cmd, Toast.LENGTH_LONG).show();
            }
            if(lastCmd0Indx>=100){
                lastCmd0Indx=0;
            }
        }
    }
    public String getCmd0(){
        String ret="";

        for(int i=0;i<=lastCmd0Indx;i++){
            if(!isnullVal(cmd0Ar[i])) {
                ret+=cmd0Ar[i];
                cmd0Ar[i]="";
            }
        }
        if(!isnullVal(ret)) {
            ret="javascript:"+ret;
            lastCmd0Indx=0;
        }
        return ret;
    }

    public static String[] cmd1Ar=new String[100];
    public static int lastCmd1Indx=0;

    public  void addCmd1(String cmd){
        if(!isnullVal(cmd)) {
            if (Arrays.asList(cmd1Ar).contains(cmd)) {
                // is valid
            } else {
                cmd1Ar[lastCmd1Indx] = cmd;
                lastCmd1Indx++;
            }
            if(lastCmd1Indx>=100){
                lastCmd1Indx=0;
            }
        }
    }
    public  String getCmd1(){
        String ret="";

        for(int i=0;i<=lastCmd1Indx;i++){
            if(!isnullVal(cmd1Ar[i])) {
                ret+=cmd1Ar[i];
                cmd1Ar[i]="";
            }
        }
        if(!isnullVal(ret)) {
            ret="javascript:"+ret;
            lastCmd1Indx=0;
        }
        return ret;
    }

    public static boolean isnullValstatic(String str){
        boolean ret=true;
        if(str != null && !str.isEmpty()) { ret=false; }
        return ret;
    }

    public static void relodBase()
    {
         exeJSstatic("javascript:relodBase();");
    }
    public static void checkScanRes()
    {
        //201706010343
        String res=readScanRes();
        if (!isnullValstatic(res)) {
            //  Toast.makeText(thisActivity , "scan result:: " + res, Toast.LENGTH_LONG).show();
            exeJSstatic("javascript:set_Barcode('"+res+"');");
        }else {
            //  Toast.makeText(thisActivity, "nothing 2 show", Toast.LENGTH_LONG).show();
        }

    }
    public static void exeJSstatic(String exec){
        WebView NWB1st = (WebView) thisActivity.findViewById(R.id.NWB1);
        NWB1st.loadUrl(exec);
    }
    static Activity thisActivity = null;
    public static String readScanRes() {

        try {
            Context context=thisActivity;
            String filename="scanRes";
            FileInputStream fis = context.openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            //Toast.makeText(this,sb.toString(), Toast.LENGTH_LONG).show();
            return sb.toString();
        } catch (FileNotFoundException e) {
            return "";
        } catch (UnsupportedEncodingException e) {
            return "";
        } catch (IOException e) {
            return "";
        }
    }

    //----------------------------------------------------
    public String DBThem="BCC:bcc;BasketAd:basketad;";
    public String bcc="";
    public String basketad="";

    public void readBaseDB(){
        String cudb= readPADB();
        String finalDB=DBThem;

        String[] parts = cudb.split(";");
        try
        {
            String bskadPart=parts[1];
            String[] parts2 = bskadPart.split(":");
            basketad=parts2[1];
        }
        catch(Exception e)
        {
            basketad="0";
        }

        try
        {
            String bccPart=parts[0];
            String[] parts3 = bccPart.split(":");
            bcc=parts3[1];
        }
        catch(Exception e)
        {
            bcc="0";
        }



        // Toast.makeText(this,"finalDB:: "+finalDB, Toast.LENGTH_LONG).show();

        // setPADB(finalDB);
    }

    public void setPADB(String prm){

        String filename = "PADB";
        String string = prm;//"BCC:"+prm+";";
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(string.getBytes());
            outputStream.close();
            //Toast.makeText(this,"write 2 file OK:: "+ string, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // Toast.makeText(this,"write 2 file ERR:: "+ prm, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
    public String readPADB() {

        try {
            Context context=this;
            String filename="PADB";
            FileInputStream fis = context.openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            //Toast.makeText(this,sb.toString(), Toast.LENGTH_LONG).show();
            return sb.toString();
        } catch (FileNotFoundException e) {
            return "";
        } catch (UnsupportedEncodingException e) {
            return "";
        } catch (IOException e) {
            return "";
        }
    }

    public void setCUDB(){
        String finalDB=DBThem;
        finalDB= finalDB.replace("bcc", bcc);
        finalDB= finalDB.replace("basketad", basketad);
        //Toast.makeText(this,"finalDB:: "+finalDB, Toast.LENGTH_LONG).show();
        setPADB(finalDB);
    }

    //----------------------------------------------------

    public void hideWait() {

        avi = (AVLoadingIndicatorView) findViewById(R.id.avi);
        avi.hide();

    }

    public AVLoadingIndicatorView avi;

    public void showWait() {

       // avi = (AVLoadingIndicatorView) findViewById(R.id.avi);
       // avi.show();


    }

    public void showInternetEr(){
        Intent intent = new Intent(this,IEActivity.class);//IO7Activity.class);// PagerActivity.class);// MainActivity.class);
        startActivity(intent);

    }

    public String lastFCId="";

    public void manageWBcommands(String msg) {

        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        if (cmd.trim().equals("winLoad")){

            try {
                InstanceID instanceID = InstanceID.getInstance(this);

                String token = instanceID.getToken(getString(R.string.gcm_defaultSenderId),
                        GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);

               // Log.i(TAG, "GCM Registration Token: " + token);
                //Toast.makeText(this,"myToken:: "+token, Toast.LENGTH_LONG).show();
devToken=token;
            }catch (Exception e) {
               // Log.d(TAG, "Failed to complete token refresh", e);
                //Toast.makeText(this,"myToken:: "+"fail......", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (cmd.trim().equals("mustReload")){
            mustReload=true;
            return;
        }
        if (cmd.trim().equals("exit")){
            finish();
            return;
        }
        if (cmd.trim().equals("internerErr")){
            //hideWait();
            haveInternetErr=true;
            //NWB1.loadUrl("file:///android_asset/myerrorpage.html");
            return;
        }

        if (cmd.trim().equals("themLoad")) {
            themLoaded = true;
        }
        if (cmd.trim().equals("serverLoad")) {
            serverLoaded = true;
        }

        if (cmd.trim().equals("changePage")) {

        }
        if (cmd.trim().equals("showWait")) {
            //showWaiter];
            showWait();
            return;
        }
        if (cmd.trim().equals("hideWait")) {
            hideWait();
            return;
        }
        if (cmd.trim().equals("doPay")) {
          /*  lastFCId = param;
            String dieUrl = "http://pandora.ir/mobile/Paymentor?fi=" + lastFCId;
            openCustomTab(dieUrl);
*/

            //  NSString* param = [foo objectAtIndex: 1];
            lastFCId=param;
            //showSafar];

            String dieUrl="http://pandora.ir/mobile/Paymentor?fi="+lastFCId;
            openCustomTab(dieUrl);


            //finishActivity(browserIntent);

           // return;

            return;
        }
        if (cmd.trim().equals("setBasketAd")) {
            String PADBC = readPADB();
            basketad = param.split(",")[0];
            bcc = param.split(",")[1];
            setCUDB();
            String exec = "javascript:setBasketAd('" + param + "');";
            addCmd1(exec);
            //Toast.makeText(this,exec, Toast.LENGTH_LONG).show();

            return;
        }
        if(cmd.trim().equals("add2Basket")){
            String exec2 = "add2Basket('"+param+"');";
            addCmd0(exec2);
            return;
        }
        if(cmd.trim().equals("Add2BOk")){
            bcc=param;
            setCUDB();
            String exec2 = "add2BOK('"+param+"');";
            addCmd1(exec2);

            return;
        }
        //--------------------
        if(cmd.trim().equals("ProdUnAv")){
            String exec2 = "add2BUnAv()";
            addCmd1(exec2);
            return;
        }
        //------------
        if(cmd.trim().equals("add2BServErr")){
            String exec2 = "servErr()";
            addCmd1(exec2);
            return;
        }
        //---------------------
        if(cmd.trim().equals("Del2B")) {
            String exec2 = "Del2B('"+param+"');";
            addCmd0(exec2);
            return;
        }
        //---------------------
        if(cmd.trim().equals("Del2BOK")){
            String exec2 = "Del2BOK();";
            addCmd1(exec2);
            return;
        }
        //-------------------
        if(cmd.trim().equals("Del2BNotOK")){
            String exec2 = "servErr()";
            addCmd1(exec2);
            return;
        }
        //-------------------
        if(cmd.trim().equals("setUsn")){
            String exec2 = "setUsn('"+param+"');";
            addCmd1(exec2);
            return;
        }
        //-------------
        if(cmd.trim().equals("setIsLogIn")){
            String exec2 = "setIsLogIn('"+param+"');";
            addCmd1(exec2);
            return;
        }
        //------------------------------
        if((cmd.trim().equals("RUNgoLogin"))){
            String exec2 = cmd+"('"+param+"#newitem#"+devToken+"');";
            addCmd0(exec2);
            return;
        }
        if((cmd.trim().equals("RUNgoReg"))||(cmd.trim().equals("RUNgoForget"))||(cmd.trim().equals("startGetFactor")) || (cmd.trim().equals("RUNgoSendCPM"))){
            String exec2 = cmd+"('"+param+"');";
            addCmd0(exec2);
            return;
        }
        //-------------------
        if(cmd.trim().equals("FacOK")){
            String exec2 = "FacOK('"+param+"');";
            addCmd1(exec2);
           // Toast.makeText(this,exec2, Toast.LENGTH_LONG).show();
            return;
        }
        if((cmd.trim().equals("popErr"))||(cmd.trim().equals("LoginOK"))||(cmd.trim().equals("RegOk"))||(cmd.trim().equals("ForgetOk"))||(cmd.trim().equals("FacOK"))||(cmd.trim().equals("sendpmOK"))||(cmd.trim().equals("sendpmERR"))){
            String exec2 = cmd+"('"+param+"');";
            addCmd1(exec2);
            return;
        }

        //------------------



        //------------
        if(cmd.trim().equals("justLog")){
            // NSString* param = [foo objectAtIndex: 1];
            //NSLog(@"\n\nJUST FOR LOG : \n\n%@", param);
            return;
        }
        //--------

        if(cmd.trim().equals("setFacResult")){
            //hideSafar];
            String exec2 = "setFacResult('"+param+"','"+foo[2]+"');";
            addCmd1(exec2);
            return;
        }

        if(cmd.trim().equals("runBarcode")){

            //barcodLoaded=false;


            Intent intent = new Intent(this,ScanActivity.class);//IO7Activity.class);// PagerActivity.class);// MainActivity.class);
            startActivity(intent);


            return;
        }
        if(cmd.trim().equals("closeBarcode")){
            //closeBarcode];
            //slidBak2Home();

            return;
        }
        if(cmd.trim().equals("runInsta")){
            lastSchem="instagram://user?username=pandoraleather";
            return;
        }
        if(cmd.trim().equals("runTeleg")){
            lastSchem="tg://resolve?domain=Pandoraleather";
            return;
        }
        if(cmd.trim().equals("openSchem")){
            lastSchem=param;
            return;
        }

    }

    private int getColor(String editText) {
        try {
            return Color.parseColor(editText);
        } catch (NumberFormatException ex) {
            //  Log.i(TAG, "Unable to parse Color: " + editText.getText());
            return Color.LTGRAY;
        }
    }
    private void openCustomTab(String ur) {

        String url0 = ur;//"https://paul.kinlan.me/";
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        int color = getColor("#980e03");
        builder.setToolbarColor(color);
        builder.setShowTitle(true);

        builder.setCloseButtonIcon(
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_arrow_back));

        builder.setStartAnimations(this, R.anim.slide_in_right, R.anim.slide_out_left);
        builder.setExitAnimations(this, android.R.anim.slide_in_left,
                android.R.anim.slide_out_right);

        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(this, Uri.parse(url0));
        //builder.setToolbarColor(colorInt);
/*
        if(false) {

            Toast.makeText(this, ur, Toast.LENGTH_LONG).show();

            String tcmd1 = "setFacResult('y','123')";
            String tcmd2 = "setFacResult('n','')";

            if (true) {

                String url = ur;

                int color = getColor("#980e03");
                int secondaryColor = getColor("#980e03");

                CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
                intentBuilder.setToolbarColor(color);
                intentBuilder.setSecondaryToolbarColor(secondaryColor);

                intentBuilder.setShowTitle(true);

                intentBuilder.setCloseButtonIcon(
                        BitmapFactory.decodeResource(getResources(), R.drawable.ic_arrow_back));

                intentBuilder.setStartAnimations(this, R.anim.slide_in_right, R.anim.slide_out_left);
                intentBuilder.setExitAnimations(this, android.R.anim.slide_in_left,
                        android.R.anim.slide_out_right);

                CustomTabActivityHelper.openCustomTab(
                        this, intentBuilder.build(), Uri.parse(url), new WebviewFallback());
            }
        }
        */
    }


    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
            manageWBcommands(message);

        }
    }

    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void onReceivedHttpError (WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            Toast.makeText(view.getContext(), "HTTP error "+errorResponse.getStatusCode(), Toast.LENGTH_LONG).show();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }
}
