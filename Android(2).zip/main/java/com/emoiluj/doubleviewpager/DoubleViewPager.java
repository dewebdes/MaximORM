package com.emoiluj.doubleviewpager;

import android.content.Context;
import android.util.AttributeSet;

public class DoubleViewPager extends HorizontalViewPager{

    public DoubleViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DoubleViewPager(Context context) {
        super(context);
    }
}