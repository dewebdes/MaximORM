﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class unknown
    {
        public string id = "0";
        public string sid = "0";
        public string ownerTbl = "0";
        public string ownerRec = "0";
        public string isSingle = "1";
        public string isExist = "0";
        public string isNew = "0";
        public string jsn = "";
        public string title = "";
        public string parent = "0";

        public Dictionary<string, string> props = new Dictionary<string, string>();

        public unknown()
        {

        }

    }
}
