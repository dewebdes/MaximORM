﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class admin
    {
        public site DieSite = new site();
        public siteAdmin DieAdmin = new siteAdmin();
        public user DieUser = new user();

        public admin()
        {

        }

    }
}
