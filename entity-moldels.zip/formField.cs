﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_FormFields
    public class formField
    {
        public string id = "";
        public string sid = "";
        public string Title = "";
        public string Type = "";
        public string Temp = "";
        public string Field = "";
        public string dieText = "";
        public string IsNull = "";
        public string Ky = "";
        public string Ord = "";
        public string Hidden = "";
        public string InId = "";
        public string Form = "";

        public formField()
        {

        }

    }
}
