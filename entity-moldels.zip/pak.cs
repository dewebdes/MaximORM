﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class pak
    {
        public string id = "";
        public string name = "";
        public string bsid = "";
        public string Date = "";

        public pak()
        {

        }

    }
}
