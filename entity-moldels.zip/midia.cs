﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_Midias
    public class midia
    {
        public string id = "";
        public string sid = "";
        public string User = "";
        public string Fn = "";
        public string Title = "";
        public string URL1 = "";
        public string URL2 = "";
        public string URL3 = "";
        public string Capt = "";
        public string Alt = "";
        public string Descibt = "";
        public string AtthId = "";
        public string CDate = "";
        
        public midia()
        {

        }

    }
}
