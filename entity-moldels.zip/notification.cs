﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_NotificationsTbl
    public class notification
    {
        //public string id = "";
        //public string usn = "";
        public string id = "";
        public string sid = "";
        public string dieUser = "";
        public string dieTitle = "";
        public string dieAction = "";
        public string dieUrl = "";
        public string dieDate = "";
        public string isRead = "";

        public notification()
        {

        }

    }
}
