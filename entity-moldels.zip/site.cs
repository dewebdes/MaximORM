﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_Sites
    public class site
    {
        public string id = "";
        public string sub = "";
        public string dm = "";
        public string usr = "";
        public string cdate = "";
        public string pak = "";
        //public List<siteAdmin> admins = new List<siteAdmin>();

        public site()
        {

        }

    }
}
