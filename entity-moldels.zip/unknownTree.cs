﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class unknownTree
    {
        public unknown rec = new unknown();
        public List<unknownTree> childs = new List<unknownTree>();

        public unknownTree()
        {
            
        }
    }
}
