﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class seo
    {
        //wp_seoProduct , wp_[classname]
        public class seoProduct
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieSlug = "";
            public string dieKeysId = "";
            public string dieFcosKey = "";
            public string dieSeoThemId = "";
            public string dieWpMediaId = "";
            public string dieTagsId = "";
            public string dieCatsId = "";
            public string dieMainCat = "";
            public string diePrice1 = "";
            public string diePrice2 = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoProduct() { }

        }
        public class seoPost
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieSlug = "";
            public string dieKeysId = "";
            public string dieFcosKey = "";
            public string dieSeoThemId = "";
            public string dieWpMediaId = "";
            public string dieTagsId = "";
            public string dieCatsId = "";
            public string dieMainCat = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoPost() { }
        }

        public class seoProductCat
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieSlug = "";
            public string dieKeysId = "";
            public string dieFcosKey = "";
            public string dieSeoThemId = "";
            public string dieWpMediaId = "";
            public string dieParent = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoProductCat() { }
        }
        public class seoProductTag
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieSlug = "";
            public string dieKeysId = "";
            public string dieFcosKey = "";
            public string dieSeoThemId = "";
            public string dieWpMediaId = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoProductTag() { }
        }

       

        public class seoPostCat
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieSlug = "";
            public string dieKeysId = "";
            public string dieFcosKey = "";
            public string dieSeoThemId = "";
            public string dieWpMediaId = "";
            public string dieParent = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoPostCat() { }
        }

        public class seoPostTag
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieSlug = "";
            public string dieKeysId = "";
            public string dieFcosKey = "";
            public string dieSeoThemId = "";
            public string dieWpMediaId = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoPostTag() { }
        }

        public class seoMedia
        {
            public string id = "0";
            public string sid = "";
            public string dieWpid = "";
            public string dieSiteUrl = "";
            public string dieUrl = "";
            public string dieTitle = "";
            public string dieMid = "";
            public string dieCaption = "";
            public string dieAlt = "";
            public string dieDesc = "";
            public string dieDate = "";
            public string dieUpdate = "";

            public seoMedia() { }
        }


        public class seoKey
        {
            public string id = "0";
            public string sid = "";
            public string dieOrder = "";
            public string dieTitle = "";
            public string dieDate = "";

            public seoKey() { }
        }

        public class seoThem
        {
            public string id = "0";
            public string dieTitle = "";
            public string dieText = "";
            public string dieSeoTitle = "";
            public string dieMetaDescrib = "";
            public string dieFocusKey = "";
            public string dieAllKeys = "";
            public string dieImage = "";
            public string dieOrder = "";
            
            public seoThem() { }
        }

        //----------------------------------- Helpers

        public class seoTree
        {
            public string id = "0";
            public string wpid = "0";
            public string sid = "0";
            public string dieParent = "0";
            public string dieRecId = "0";
            public string dieTyp = "";
            public string dieTitle = "";
            public string dieUrl = "";//tablename#recid
            public string dieSiteUrl = "";
            public string dieIsPublished = "";
            public string dieImg = "";
            

            public seoTree() { }
        }

        public class seoX
        {
            public string ur = "";

            public seoX() { }
        }

    }
}
