﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_TableFields
    public class tableField
    {
        public string id = "";
        public string sid = "";
        public string Title = "";
        public string Type = "";
        public string Temp = "";
        public string Def = "";
        public string Ord = "";
        public string Multival = "";
        public string Hidden = "";
        public string InId = "";
        public string Tbl = "";

        public tableField()
        {

        }

    }
}
