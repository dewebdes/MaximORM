﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_MMedia
    public class mmedia
    {
        public string id = "";
        public string sid = "";
        public string usid = "";
        public string Title = "";
        public string URL1 = "";
        public string URL2 = "";
        public string URL3 = "";
        public string Caption = "";
        public string Alt = "";
        public string Desc = "";
        public string AtthId = "";
        public string CDate = "";
        
        public mmedia()
        {

        }

    }
}
