﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_Tables
    public class table
    {
        public string id = "";
        public string sid = "";
        public string Title = "";
        public string Parent = "";
        public string Date = "";

        public table()
        {

        }

    }
}
