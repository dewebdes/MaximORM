﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class fullTable
    {
        public table tbl = new table();
        public List<tableField> flist = new List<tableField>();
        public List<form> forms = new List<form>();

        public fullTable()
        {

        }

    }
}
