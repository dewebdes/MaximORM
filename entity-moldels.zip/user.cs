﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_Users
    public class user
    {
        public string id = "";
        public string usn = "";
        public string pss = "";
        public string mail = "";
        public string fname = "";
        public string lname = "";
        public string mob = "";
        public string cdate = "";

        public user() { }
    }
}
