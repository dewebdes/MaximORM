﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class shortcut
    {
        public string id = "";
        public string name = "";
        public string place = "";
        public string func = "";
        public string order = "";
        public string rol = "";
        public string parent = "";
        public string img = "";

        public shortcut() {

        }

    }
}
