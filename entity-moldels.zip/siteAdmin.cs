﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    //wp_SiteAdmins
    public class siteAdmin
    {
        public string id = "";
        public string sid = "";
        public string usid = "";
        public string usn = "";
        public string pss = "";
        public string rol = "";
        public string cdate = "";
        public string fullname = "";
        public string mail = "";
        public string mob = "";

        public siteAdmin()
        {

        }

    }
}
