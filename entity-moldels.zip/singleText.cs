﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxReseller.Models
{
    public class singleText
    {
        public string sid = "";
        public string tx = "";

        public singleText()
        {

        }

    }
}
