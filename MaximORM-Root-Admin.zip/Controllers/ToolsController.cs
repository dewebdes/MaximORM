﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MAXIMPanel.Controllers
{
    public class ToolsController : Controller
    {
        // GET: Tools
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult NewTable()
        {
            return View();
        }
        public ActionResult EditTable()
        {
            return View();
        }
       
        public ActionResult OpenTable()
        {
            return View();
        }
        public ActionResult NewForm()
        {
            return View();
        }
        public ActionResult EditForm()
        {
            return View();
        }
      
        public ActionResult OpenForm()
        {
            return View();
        }
        public ActionResult SelectTable()
        {
            return View();
        }
        public ActionResult MediaManager()
        {
            return View();
        }
        public ActionResult AddMedia()
        {
            return View();
        }
        public ActionResult MediaList()
        {
            return View();
        }
        public ActionResult TextFile()
        {
            return View();
        }

    }
}