﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MAXIMPanel.Controllers
{
    public class FormHandlerController : Controller
    {
        // GET: FormHandler
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Render()
        {
            return View();
        }
        public ActionResult Open()
        {
            return View();
        }
        public ActionResult TreeBlack()
        {
            return View();
        }
        public ActionResult Render_TextBox()
        {
            return View();
        }

        //--------------- Field Render Views -----------------
//first do 11 field then do others


        public ActionResult FieldRender_Lable()
        {
            return View();
        }
        public ActionResult FieldRender_Help()
        {
            return View();
        }
        public ActionResult FieldRender_Config()
        {
            return View();
        }
        public ActionResult FieldRender_int()
        {
            return View();
        }
        public ActionResult FieldRender_long()
        {
            return View();
        }
        public ActionResult FieldRender_currency()
        {
            return View();
        }
        public ActionResult FieldRender_date()
        {
            return View();
        }
        public ActionResult FieldRender_textbox()
        {
            return View();
        }
        public ActionResult FieldRender_text_describ()
        {
            return View();
        }

        
        public ActionResult FieldRender_text_file()
        {
            return View();
        }

        
        public ActionResult FieldRender_text_article()
        {
            return View();
        }
        public ActionResult FieldRender_boolean()
        {
            return View();
        }

        public ActionResult FieldRender_list_new()
        {
            return View();
        }
        public ActionResult FieldRender_list_exist()
        {
            return View();
        }
        public ActionResult FieldRender_file()
        {
            return View();
        }
        public ActionResult FieldRender_combo_box()
        {
            return View();
        }
        
        public ActionResult FieldRender_list_single()
        {
            return View();
        }

        public ActionResult FieldRender_inner_grid_ext()
        {
            return View();
        }
        public ActionResult FieldRender_inner_grid_boot()
        {
            return View();
        }

        
        public ActionResult FieldRender_list_checkBox()
        {
            return View();
        }
        public ActionResult FieldRender_combo_table()
        {
            return View();
        }
        public ActionResult FieldRender_user()
        {
            return View();
        }
        public ActionResult FieldRender_Title()
        {
            return View();
        }
        public ActionResult FieldRender_Parent0()
        {
            return View();
        }
        public ActionResult FieldRender_Parent()
        {
            return View();
        }
        public ActionResult FieldRender_Fields_Combo()
        {
            return View();
        }

        public ActionResult FieldRender_AutoComplete0()
        {
            return View();
        }
        public ActionResult FieldRender_AutoComplete()
        {
            return View();
        }
        public ActionResult FieldRender_tree_list_windows()
        {
            return View();
        }

        
        public ActionResult FieldRender_tree_list_black()
        {
            return View();
        }

        public ActionResult FieldRender_image_check_list_mdl()
        {
            return View();
        }

        public ActionResult FieldRender_image_radio_list_mdl()
        {
            return View();
        }
        public ActionResult FieldRender_RenderForm_BTN()
        {
            return View();
        }
        public ActionResult FieldRender_RenderForm_Frame()
        {
            return View();
        }

        public ActionResult FieldRender_User_Multi()
        {
            return View();
        }
        public ActionResult FieldRender_User_Single()
        {
            return View();
        }

        public ActionResult FieldRender_Record_Pointer()
        {
            return View();
        }
        public ActionResult FieldRender_Update()
        {
            return View();
        }
        public ActionResult FieldRender_AutoTextFill()
        {
            return View();
        }

        //----------------------------------------------------
    }
}