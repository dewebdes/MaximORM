﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MAXIMPanel.Controllers
{
    [ActionFilters]
    public class ShellController : Controller
    {
        public Dictionary<string, string> nc = new Dictionary<string, string>();
        public string query = "";
        public string qret = "";
        public string resell = System.Configuration.ConfigurationManager.AppSettings["resell"].ToString();
        public string AdminSecret = System.Configuration.ConfigurationManager.AppSettings["AdminSecret"].ToString();
        public AppHelper aph = new AppHelper();
        public BST_PublicHelper.PubFuncs pf = new BST_PublicHelper.PubFuncs();


        void runSetup(string[] rp)
        {
            ////pf.cleanLog();
            var csec = rp[0].Trim();
            ////////////////////pf.SaveLog("runsetup");
            if (csec == AdminSecret)
            {
                //cmd="setup"
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "setup");
                ////////////////////pf.SaveLog("send form");
                ViewBag.outp = aph.sendForm(nc);
                ////////////////////pf.SaveLog(ViewBag.outp);
            }
        }
        void doAddUser(string[] rp)
        {
            ////pf.cleanLog();
            var usn = rp[0].Trim().ToLower();
            var pss = rp[1].Trim();
            var mail = rp[2].Trim();
            var fname = rp[3].Trim();
            var lname = rp[4].Trim();
            var mob = rp[5].Trim();
            var cdate = DateTime.Now.ToString();

            var usl = aph.getUsersList();
            var exi = false;
            if (pf.canSeekL<MaxReseller.Models.user>(usl))
            {
                exi = usl.Where(a => (a.usn.ToLower() == usn.ToLower()) || (a.mail.ToLower() == mail.ToLower())).Any();
            }
            if (exi == true)
            {
                ViewBag.outp = "userExist";
            }
            else
            {
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                //nc.Add("sid", "0");
                query = "";
                query = "insert into wp_Users (usn,pss,mail,fname,lname,mob,cdate) values(#sq#" + usn + "#sq#,#sq#" + pss + "#sq#,#sq#" + mail + "#sq#,#sq#" + fname + "#sq#,#sq#" + lname + "#sq#,#sq#" + mob + "#sq#,#sq#" + cdate + "#sq#)";

                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ////////////////////pf.SaveLog(qret);
                ViewBag.outp = "userAdd";
            }

        }
        void doAddSite(string[] rp)
        {
            ////pf.cleanLog();
            var sub = rp[0].Trim().ToLower();
            var dm = rp[1].Trim().ToLower();
            var usr = rp[2].Trim().ToLower();
            var pak = rp[3].Trim().ToLower();
            var cdate2 = DateTime.Now.ToString();

            var ssl = aph.getSitesList();
            var exi2 = false;
            if (pf.canSeekL<MaxReseller.Models.site>(ssl))
            {
                exi2 = ssl.Where(a => (a.sub.ToLower() == sub.ToLower()) || ((!String.IsNullOrEmpty(dm)) && (a.dm.ToLower() == dm.ToLower()))).Any();
            }
            if (exi2 == true)
            {
                ViewBag.outp = "siteExist";
            }
            else
            {
                var dieUs = aph.getSingleUser(usr);

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                ////nc.Add("sid", "0");
                query = "";
                query = "insert into wp_Sites (sub,dm,usr,cdate,pak) values(#sq#" + sub + "#sq#,#sq#" + dm + "#sq#,#sq#" + usr + "#sq#,#sq#" + cdate2 + "#sq#,#sq#" + pak + "#sq#)";

                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ////////////////////pf.SaveLog(qret);

                //---- add site admin
                var dieSite = aph.getSingleSite(sub, dm);
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                ////nc.Add("sid", "0");
                query = "";
                query = "insert into wp_SiteAdmins (sid,usid,usn,pss,rol,cdate,fullname,mail,mob) values("
                    + dieSite.id + "," + dieUs.id + ",#sq#" + usr + "#sq#"
                    + ",#sq#" + "" + "#sq#,#sq#" + "superAdmin" + "#sq#"
                    + ",#sq#" + cdate2 + "#sq#,#sq##sq#,#sq##sq#,#sq##sq#)";


                nc.Add("query", query);
                qret += Environment.NewLine + aph.sendForm(nc);
                //--=---

                ViewBag.outp = "siteAdd";
            }

        }
        void doLoginResell(string[] rp)
        {
            ////pf.cleanLog();
            var usn1 = rp[0].Trim();
            var pss1 = rp[1].Trim();

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            //nc.Add("sid", "0");
            query = "";
            query = "select * from wp_Users where (usn=#sq#" + usn1 + "#sq#) and (pss=#sq#" + pss1 + "#sq#)";

            nc.Add("query", query);
            qret = aph.sendForm(nc);
            ////////////////////pf.SaveLog("a : "+qret);
            if (qret == "bug")
            {
                ////////////////////pf.SaveLog("err 1");
                ViewBag.outp = "badInfo";
            }
            else
            {
                try
                {
                    var tus = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.user>>(qret).First();
                    if (tus != null)
                    {
                        ViewBag.outp = "loginOk";
                        Session["user"] = usn1;
                    }
                    else
                    {
                        ////////////////////pf.SaveLog("err 2");
                        ViewBag.outp = "badInfo";
                    }
                }
                catch
                {
                    ////////////////////pf.SaveLog("err 3");
                    ViewBag.outp = "badInfo";
                }
            }

        }
        void doLoginPanel(string[] rp)
        {
            ////pf.cleanLog();
            var usn2 = rp[0].Trim().ToLower();
            var pss2 = rp[1].Trim();
            var sdm = rp[2].Trim().ToLower();

            var dieSite = new MaxReseller.Models.site();

            Int64? sid = 0;
            try
            {
                var tsub = "";
                var tdm = "";
                if (sdm.ToLower().Contains(resell.ToLower()))
                {
                    tsub = sdm.ToLower().Replace(resell.ToLower(), "").Replace(".", "");
                }
                else
                {
                    tsub = sdm.ToLower();
                    tdm = sdm.ToLower();
                }
                //////////////////pf.SaveLog("tdm : " + tdm + " , tsub : " + tsub);
                dieSite = aph.getSingleSite(tsub, tdm);
                sid = Convert.ToInt64(dieSite.id);
                if (sid == null)
                {
                    sid = 0;
                }
            }
            catch
            {
                sid = 0;
            }
            if (sid > 0)
            {

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                query = "";
                query = "select * from wp_SiteAdmins where (usn=N#sq#" + usn2 + "#sq#) and (sid=" + sid + ")";
                //pf.cleanLog();
                //////////pf.SaveLog("query : " + query);
                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ////////////////////pf.SaveLog(qret);
                if (qret == "bug")
                {
                    ////////////////pf.SaveLog("err 1");

                    ViewBag.outp = "badInfo";
                }
                else
                {
                    try
                    {
                        var tadmin = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.siteAdmin>>(qret).First();
                        if (tadmin != null)
                        {
                            ViewBag.outp = "loginOk";
                            var dieAdmin = new MaxReseller.Models.admin();

                            dieAdmin.DieAdmin = tadmin;
                            dieAdmin.DieSite = dieSite;

                            if (tadmin.usid == "0")
                            {
                                if (tadmin.pss == pss2)
                                {
                                    dieAdmin.DieUser = null;
                                }
                                else
                                {
                                    ViewBag.outp = "badInfo";
                                    ////////////////pf.SaveLog("err 2");

                                }
                            }
                            else
                            {
                                var dieUser = aph.getSingleUser(usn2);
                                if (dieUser.pss == pss2)
                                {
                                    dieAdmin.DieUser = dieUser;
                                }
                                else
                                {
                                    ViewBag.outp = "badInfo";
                                    ////////////////pf.SaveLog("err 3");

                                }
                            }

                            if (ViewBag.outp == "loginOk")
                            {
                                Session["cuAdmin"] = dieAdmin;
                            }
                        }
                        else
                        {
                            ViewBag.outp = "badInfo";
                            ////////////////pf.SaveLog("err 4");

                        }
                    }
                    catch
                    {
                        ViewBag.outp = "badInfo";
                        ////////////////pf.SaveLog("err 5");

                    }
                }
            }
            else
            {
                ViewBag.outp = "badInfo";
                ////////////////pf.SaveLog("err 6");

            }
            //////////pf.SaveLog(ViewBag.outp);
        }

        void getuscommandlist(string[] rp)
        {
            ViewBag.outp = "";

            var cmdMod = rp[0];

            if (cmdMod == "isLogin")
            {
                //bak2Login
                var DieAdmin = aph.getDieAdmin();
                if (DieAdmin == null)
                {
                    ViewBag.outp = "bak2Login";
                }
            }

        }

        void getTableName(string[] rp)
        {
            ////pf.cleanLog();
            var str = rp[0].Trim();
            var ifi = rp[1].Trim();

            ViewBag.str = str;
            ViewBag.ifi = ifi;

            var usl = aph.getTablesList();
            var exi = false;
            if (pf.canSeekL<MaxReseller.Models.table>(usl))
            {
                exi = usl.Where(a => (a.Title.ToLower() == str.ToLower())).Any();
            }
            if (exi == true)
            {
                ViewBag.outp = "tableExist";
            }
            else
            {
                ViewBag.outp = "tableFree";
            }

        }
        void getFormName(string[] rp)
        {
            ////pf.cleanLog();
            var str = rp[0].Trim();
            var ifi = rp[1].Trim();
            var tbl = rp[2].Trim();

            ViewBag.str = str;
            ViewBag.ifi = ifi;

            var usl = aph.getTableForms(tbl);
            var exi = false;
            if (pf.canSeekL<MaxReseller.Models.form>(usl))
            {
                exi = usl.Where(a => (a.Title.ToLower() == str.ToLower())).Any();
            }
            if (exi == true)
            {
                ViewBag.outp = "FormExist";
            }
            else
            {
                ViewBag.outp = "FormFree";
            }

        }

        void doChangePass(string[] rp)
        {
            var tblId = rp[0].Trim().ToLower();
            var rcId = rp[1].Trim().ToLower();
            var names = rp[2].Trim();//.ToLower();
            var vals = rp[3].Trim();//.ToLower();

            var fldAr = pf.vbsplit(names, "sspp");
            var valAr = pf.vbsplit(vals, "sspp");
            var valAr2 = valAr;

            var dieAdmin = aph.getDieAdmin();
            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Update", null);
            if (canDo == true)
            {

                string sid = dieAdmin.DieAdmin.sid;
                string cuPass = valAr[0];
                string newPass = valAr[1];

                var cuPassOk = false;
                if (dieAdmin.DieAdmin.usid == "0")
                {
                    if (dieAdmin.DieAdmin.pss == cuPass)
                    {
                        cuPassOk = true;
                    }
                }
                else
                {
                    if (dieAdmin.DieUser.pss == cuPass)
                    {
                        cuPassOk = true;
                    }
                }

                if (cuPassOk == true)
                {

                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    if (dieAdmin.DieAdmin.usid == "0")
                    {
                        query = "update wp_SiteAdmins set pss='" + newPass + "' where id=" + dieAdmin.DieAdmin.id;
                    }
                    else
                    {
                        query = "update wp_Users set pss='" + newPass + "' where id=" + dieAdmin.DieAdmin.usid;
                    }
                    query = query.Replace("'", "#sq#");
                    nc.Add("query", query);
                    qret = aph.sendForm(nc);
                    ViewBag.outp = "ActionDone";
                }
                else
                {
                    ViewBag.outp = "CuPassWrong";
                }
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }

        }
        void doInserInUser(string[] rp)
        {
            ////pf.cleanLog();

            //////////////pf.SaveLog("****** in insrt 1");

            var tblId = rp[0].Trim().ToLower();
            var names = rp[1].Trim();//.ToLower();
            var vals = rp[2].Trim();//.ToLower();
            var fldAr = pf.vbsplit(names, "sspp");
            var valAr = pf.vbsplit(vals, "sspp");
            var valAr2 = valAr;

            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;
            string usid = "0";
            string usn = valAr[1];
            string pss = valAr[2];
            string rol = valAr[3];
            string cdate = valAr[0];
            string fullname = valAr[4];
            string mail = valAr[5];
            string mob = valAr[6];


            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Insert", null);


            if (canDo == true)
            {

                var exi = aph.canAddUser(usn);

                if (exi == true)
                {

                    //////////pf.SaveLog("****** in insrt 4");

                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    query = "insert into wp_SiteAdmins " + "(sid,usid,usn,pss,rol,cdate,fullname,mail,mob) values(";
                    query += dieAdmin.DieSite.id + ",";
                    query += usid + ",'" + usn + "','" + pss + "','" + rol + "','" + cdate + "','" + fullname + "','" + mail + "','" + mob + "')";
                    query = query.Replace("'", "#sq#");
                    nc.Add("query", query);
                    //pf.cleanLog();
                    //////////pf.SaveLog("query : " + query);
                    ////////////pf.SaveLog("****** in insrt 7");
                    try
                    {
                        qret = aph.sendForm(nc);
                    }
                    catch (Exception ex)
                    {
                        pf.SaveErr(ex, "insertUser");
                    }

                    //////////pf.SaveLog("qret : " + qret);
                    ViewBag.outp = "ActionDone";
                }
                else
                {
                    ViewBag.outp = "UserExist";
                }

            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }
            ////////////pf.SaveLog("****** in insrt 25");
        }
        void doUpdateUser(string[] rp)
        {
            var tblId = rp[0].Trim().ToLower();
            var rcId = rp[1].Trim().ToLower();
            var names = rp[2].Trim();//.ToLower();
            var vals = rp[3].Trim();//.ToLower();

            var fldAr = pf.vbsplit(names, "sspp");
            var valAr = pf.vbsplit(vals, "sspp");
            var valAr2 = valAr;

            var dieAdmin = aph.getDieAdmin();
            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Update", null);
            if (canDo == true)
            {

                string sid = dieAdmin.DieAdmin.sid;
                string usid = "0";
                string usn = valAr[1];
                string pss = valAr[2];
                string rol = valAr[3];
                string cdate = valAr[0];
                string fullname = valAr[4];
                string mail = valAr[5];
                string mob = valAr[6];


                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                query = "update wp_SiteAdmins set ";// sid=" + dieAdmin.DieSite.id + ",";

                //query+= "usn=''
                query += "pss='" + pss + "',";
                query += "rol='" + rol + "',";
                query += "cdate='" + cdate + "',";
                query += "fullname='" + fullname + "',";
                query += "mail='" + mail + "',";
                query += "mob='" + mob + "'";

                query += " where (sid=" + dieAdmin.DieSite.id + ") and (id=" + rcId + ")";
                query = query.Replace("'", "#sq#");
                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ViewBag.outp = "ActionDone";
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }

        }
        void doDeleteFromUser(string[] rp)
        {
            ////pf.cleanLog();

            var tblId = rp[0].Trim().ToLower();
            var ids = rp[1].Trim().ToLower();
            //if(ids.EndsWith(""))

            var dieAdmin = aph.getDieAdmin();
            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Del", null);
            if (canDo == true)
            {
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                query = "delete from wp_SiteAdmins where (sid=" + dieAdmin.DieAdmin.sid + ") and (id in (" + ids + "))";
                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ViewBag.outp = "ActionDone";
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }
        }

        void doDeleteFromTbl(string[] rp)
        {
            var string_cmd = "doInserInTable";
            var string_frmId = "";
            var string_tblId = "";
            var string_recId = "";
            ////pf.cleanLog();

            string_frmId = Session["frmId"].ToString();
            ////pf.cleanLog();

            var tblId = rp[0].Trim().ToLower();
            var ids = rp[1].Trim().ToLower();
            //if(ids.EndsWith(""))

            string_tblId = tblId;
            string_recId = ids;

            var dieAdmin = aph.getDieAdmin();
            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Del", null);
            if (canDo == true)
            {
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                query = "delete from wp_" + tblN + " where (sid=" + dieAdmin.DieAdmin.sid + ") and (id in (" + ids + "))";
                nc.Add("query", query);
                //////////////////pf.SaveLog(query);
                qret = aph.sendForm(nc);
                //////////////////pf.SaveLog(qret);
                ViewBag.outp = "ActionDone";
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }
            aph.runAfterAction(string_cmd, string_frmId, string_tblId, string_recId);
        }
        void doInserInTable(string[] rp)
        {
            var string_cmd = "doInserInTable";
            var string_frmId = "";
            var string_tblId = "";
            var string_recId = "";
            ////pf.cleanLog();

            string_frmId = Session["frmId"].ToString();

            //////////pf.SaveLog("****** in insrt 1");

            var tblId = rp[0].Trim().ToLower();
            var names = rp[1].Trim();//.ToLower();
            var vals = rp[2].Trim();//.ToLower();
            var fldAr = pf.vbsplit(names, "sspp");
            var valAr = pf.vbsplit(vals, "sspp");
            var valAr2 = valAr;


            string_tblId = tblId;

            //////////pf.SaveLog("****** in insrt 2");

            for (var i = 0; i <= fldAr.Length - 1; i++)
            {
                //////////////pf.SaveLog(fldAr[i] + " = " + valAr[i]);
            }

            var dieAdmin = aph.getDieAdmin();
            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Insert", null);

            //////////pf.SaveLog("****** in insrt 3");

            if (canDo == true)
            {
                //////////pf.SaveLog("****** in insrt 4");

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                query = "insert into wp_" + tblN + " (sid," + fldAr.ToList().Aggregate((a, b) => a + "," + b) + ") values(";
                query += dieAdmin.DieSite.id + ",";

                //////////pf.SaveLog("****** in insrt 5");

                for (var i = 0; i <= valAr.Length - 1; i++)
                {
                    var v = valAr[i];
                    try
                    {
                        var tint = Convert.ToDouble(v);
                        if (v.Contains(","))
                        {
                            valAr2[i] = "#sq#" + v + "#sq#";
                        }
                        else
                        {
                            if (v.Contains(".") == true)
                            {
                                valAr2[i] = "#sq#" + v + "#sq#";
                            }
                            else
                            {
                                valAr2[i] = v;
                            }
                            
                        }
                        //query += v;
                    }
                    catch
                    {
                        valAr2[i] = "#sq#" + v + "#sq#";
                        //query+= "#sq#" + v + "#sq#";
                    }
                    //if (i < valAr.Count() - 1)
                    //{
                    //    query += ",";
                    //}
                    //else
                    //{
                    //    query += ")";
                    //}
                }

                //////////pf.SaveLog("****** in insrt 6 = " + fldAr.Length + " = " + valAr2.Length);

                query += valAr2.ToList().Aggregate((a, b) => a + "," + b) + ")";

                //for(var i = 0; i <= valAr2.Count() - 1; i++)
                //{
                //    query += valAr2[i];
                //    if (i < valAr2.Count() - 1)
                //    {
                //        query += ",";
                //    }
                //    else
                //    {
                //        query += ")";
                //    }
                //}

                nc.Add("query", query);
                ////pf.cleanLog();
                pf.SaveLog("********************insert query : " + query);
                ////////////pf.SaveLog("****** in insrt 7");
                try
                {
                    qret = aph.sendForm(nc);
                }
                catch (Exception ex)
                {
                   //pf.SaveLog("------------------------inser err : " + pf.SaveErr(ex, "insert"));
                }
                //pf.SaveLog("****** in insrt 8");
                //////////pf.SaveLog("qret : " + qret);
                ViewBag.outp = "ActionDone";
               //pf.SaveLog("****** in insrt 9");

                //---------- special handels
                //var dieAdmin = aph.getDieAdmin();
                var sid = dieAdmin.DieAdmin.sid;
                var pakSid = aph.getPakInfo(dieAdmin.DieSite.pak).bsid;

                //pf.SaveLog("****** in insrt 10");

                //var recsJsnLast = aph.getTableLastRecord(tblId, sid, pakSid, 1);
                var recsJsnLast = aph.getTableLastRecord_2(tblN, sid, 1);
                //pf.SaveLog("recsJsnLast : " + recsJsnLast);
                var unLLast = (new MaxReseller.Funcs.jsonify()).getUnknownList(recsJsnLast);
                ////////////pf.SaveLog((unLLast == null).ToString());
                var lastRC = unLLast.First();
                var newId = lastRC.id;

                string_recId = newId;

               //pf.SaveLog("****** in insrt 11");

                var tblFls = aph.getTableFields(tblId);
                //var specFlds = tblFls.Where(a => (a.Type == "list-new") || (a.Type == "list-exist") || (a.Type == "list-single")).ToList();
                var specFlds = tblFls.Where(a => (a.Type == "list-new")).ToList();

               //pf.SaveLog("****** in insrt 12");

                if (pf.canSeekL<MaxReseller.Models.tableField>(specFlds) == true)
                {
                    //pf.SaveLog("****** in insrt 13");
                    foreach (var f in specFlds)
                    {
                        ////////////pf.SaveLog("****** in insrt 14");
                        for (var i = 0; i <= fldAr.Length - 1; i++)
                        {
                            ////////////pf.SaveLog("****** in insrt 15 : "+ fldAr[i]+" = "+ f.Title);
                            if (fldAr[i].ToLower() == f.Title.ToLower())
                            {
                                ////////////pf.SaveLog("****** in insrt 16");
                                var tvl = valAr2[i].Replace("#sq#", "");
                                if (!String.IsNullOrWhiteSpace(tvl))
                                {
                                    ////////////pf.SaveLog("****** in insrt 17 : " + valAr2[i] + " - " + tvl);
                                    var tidAr = pf.vbsplit(tvl, ",");
                                    foreach (var d in tidAr)
                                    {
                                        ////////////pf.SaveLog("****** in insrt 18");
                                        var def = f.Def;
                                        var maxJsn = new MaxReseller.Funcs.jsonify();
                                        var defObj = maxJsn.getRelatedObj(def);
                                        var ftbl = "";
                                        ////////////pf.SaveLog("****** in insrt 19");
                                        try
                                        {
                                            ftbl = defObj.tbls[0];
                                            if (String.IsNullOrWhiteSpace(ftbl))
                                            {
                                                ftbl = "";
                                            }
                                        }
                                        catch
                                        {
                                            ftbl = "";
                                        }
                                        ////////////pf.SaveLog("****** in insrt 20");
                                        if (!String.IsNullOrWhiteSpace(ftbl))
                                        {
                                            ////////////pf.SaveLog("****** in insrt 21");
                                            //tbl : ftbl , id: d
                                            var tblInfo = aph.getTableInfo(ftbl);
                                            nc = new Dictionary<string, string>();
                                            nc.Add("cmd", "RunQuery");
                                            query = "";
                                            query = "update wp_" + tblInfo.Title + " set ";// sid=" + dieAdmin.DieSite.id + ",";
                                            query += "ownerRec=" + newId;
                                            query += " where (sid=" + dieAdmin.DieSite.id + ") and (id=" + d + ") and (ownerRec=0)";
                                            ////////////pf.SaveLog("****** in insrt 22 : " + query);
                                            nc.Add("query", query);
                                            qret = aph.sendForm(nc);
                                            ////////////pf.SaveLog("****** in insrt 23 = "+qret);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                //-----------------------------
                ////////////pf.SaveLog("****** in insrt 24");
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }
            ////////////pf.SaveLog("****** in insrt 25");



            aph.runAfterAction(string_cmd, string_frmId, string_tblId, string_recId);


        }
        void doUpdateTable(string[] rp)
        {
            var string_cmd = "doUpdateTable";
            var string_frmId = "";
            var string_tblId = "";
            var string_recId = "";

            string_frmId = Session["frmId"].ToString();

            var tblId = rp[0].Trim().ToLower();
            var rcId = rp[1].Trim().ToLower();
            var names = rp[2].Trim();//.ToLower();
            var vals = rp[3].Trim();//.ToLower();

            string_tblId = tblId;
            string_recId = rcId;

            var fldAr = pf.vbsplit(names, "sspp");
            var valAr = pf.vbsplit(vals, "sspp");
            var valAr2 = valAr;

            var dieAdmin = aph.getDieAdmin();
            var tblN = aph.getTableInfo(tblId).Title;
            var canDo = aph.usHavPermission(tblN, "Update", null);
            if (canDo == true)
            {
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                query = "update wp_" + tblN + " set ";// sid=" + dieAdmin.DieSite.id + ",";
                //+ fldAr.ToList().Aggregate((a, b) => a + "," + b) + ") values(";
                //query += dieAdmin.DieSite.id + ",";
                for (var i = 0; i <= valAr.Length - 1; i++)
                {
                    var v = valAr[i];
                    try
                    {
                        var tint = Convert.ToDouble(v);
                        if (v.Contains(","))
                        {
                            valAr2[i] = "#sq#" + v + "#sq#";
                        }
                        else
                        {
                            if (v.Contains(".") == true)
                            {
                                valAr2[i] = "#sq#" + v + "#sq#";
                            }
                            else
                            {
                                valAr2[i] = v;
                            }
                            //valAr2[i] = v;
                        }
                        //query += v;
                    }
                    catch
                    {
                        valAr2[i] = "#sq#" + v + "#sq#";
                        //query+= "#sq#" + v + "#sq#";
                    }
                    //if (i < valAr.Count() - 1)
                    //{
                    //    query += ",";
                    //}
                    //else
                    //{
                    //    query += ")";
                    //}
                }
                for (var i = 0; i <= valAr.Length - 1; i++)
                {
                    var v = valAr2[i];
                    var f = fldAr[i];
                    query += f + "=" + v;
                    if (i < valAr.Length - 1)
                    {
                        query += ",";
                    }
                    else
                    {
                        //query += ")";
                    }
                }
                query += " where (sid=" + dieAdmin.DieSite.id + ") and (id=" + rcId + ")";

                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ViewBag.outp = "ActionDone";
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }

            aph.runAfterAction(string_cmd, string_frmId, string_tblId, string_recId);

        }
        void doCopyInTbl(string[] rp)
        {
            var newId = "0";
            var tblId = rp[0].Trim().ToLower();
            var rcId = rp[1].Trim().ToLower();

            var dieAdmin = aph.getDieAdmin();
            var sid = dieAdmin.DieAdmin.sid;
            var pakSid = aph.getPakInfo(dieAdmin.DieSite.pak).bsid;

            var recsJsn = aph.getTableRecordEine(tblId, sid, pakSid, rcId);
            var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(recsJsn);
            //var dieRec
            if (pf.canSeekL<MaxReseller.Models.unknown>(unL))
            {
                var cuTblRec = unL.First();

                var names = "";
                var vals = "";

                foreach (var p in cuTblRec.props)
                {
                    names += p.Key + "sspp";
                    vals += p.Value + "sspp";
                }

                names += "ownerTbl" + "sspp";
                names += "ownerRec" + "sspp";
                names += "isSingle" + "sspp";
                names += "isExist" + "sspp";
                names += "isNew";// + "sspp";

                vals += cuTblRec.ownerTbl + "sspp";
                vals += cuTblRec.ownerRec + "sspp";
                vals += cuTblRec.isSingle + "sspp";
                vals += cuTblRec.isExist + "sspp";
                vals += cuTblRec.isNew;// + "sspp";


                var fldAr = pf.vbsplit(names, "sspp");
                var valAr = pf.vbsplit(vals, "sspp");
                var valAr2 = valAr;


                var tblN = aph.getTableInfo(tblId).Title;
                var canDo = aph.usHavPermission(tblN, "Copy", null);
                if (canDo == true)
                {
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    query = "insert into wp_" + tblN + " (sid," + fldAr.ToList().Aggregate((a, b) => a + "," + b) + ") values(";
                    query += dieAdmin.DieSite.id + ",";
                    for (var i = 0; i <= valAr.Length - 1; i++)
                    {
                        var v = valAr[i];
                        try
                        {
                            if (v.Contains(","))
                            {
                                valAr2[i] = "#sq#" + v + "#sq#";
                            }
                            else
                            {
                                var tint = Convert.ToDouble(v);
                                valAr2[i] = v;
                            }
                        }
                        catch
                        {
                            valAr2[i] = "#sq#" + v + "#sq#";
                        }
                    }
                    query += valAr2.ToList().Aggregate((a, b) => a + "," + b) + ")";
                    ////pf.cleanLog();
                    ////////////////pf.SaveLog(DateTime.Now.Ticks + " = " + query);
                    nc.Add("query", query);
                    qret = aph.sendForm(nc);
                    ////////////////pf.SaveLog(qret);
                    ViewBag.outp = "ActionDone";
                    ////////////////pf.SaveLog("**************************** 1");
                    var recsJsnLast = aph.getTableLastRecord(tblId, sid, pakSid, 1);
                    ////////////////pf.SaveLog("**************************** 2");
                    var unLLast = (new MaxReseller.Funcs.jsonify()).getUnknownList(recsJsnLast);
                    ////////////////pf.SaveLog("**************************** 3");
                    var lastRC = unLLast.First();
                    ////////////////pf.SaveLog("**************************** 4");
                    newId = lastRC.id;
                    //////pf.SaveLog("new id create from copy : " + newId);

                    ViewBag.newId = newId;



                    //--------------------------

                    

                    var tblFls = aph.getTableFields(tblId);
                    //var specFlds = tblFls.Where(a => (a.Type == "list-new") || (a.Type == "list-exist") || (a.Type == "list-single")).ToList();
                    var specFlds = tblFls.Where(a => (a.Type == "list-new")).ToList();

                    ////////pf.SaveLog("****** in insrt 12");

                    if (pf.canSeekL<MaxReseller.Models.tableField>(specFlds) == true)
                    {
                        ////////////pf.SaveLog("****** in insrt 13");
                        foreach (var f in specFlds)
                        {
                            //////pf.SaveLog("****** in copy field : " + f.Title);

                            //continue;

                            for (var i = 0; i <= fldAr.Length - 1; i++)
                            {
                                ////////////pf.SaveLog("****** in insrt 15 : "+ fldAr[i]+" = "+ f.Title);
                                if (fldAr[i].ToLower() == f.Title.ToLower())
                                {
                                    ////////////pf.SaveLog("****** in insrt 16");
                                    var tvl = valAr2[i].Replace("#sq#", "");
                                    if (!String.IsNullOrWhiteSpace(tvl))
                                    {
                                        //////pf.SaveLog("****** vals for " + f.Title + " : " + tvl);
                                        var tidAr = pf.vbsplit(tvl, ",");

                                        var newTvl = new List<string>();

                                        foreach (var d in tidAr)
                                        {
                                            ////////////pf.SaveLog("****** in insrt 18");
                                            var def = f.Def;
                                            var maxJsn = new MaxReseller.Funcs.jsonify();
                                            var defObj = maxJsn.getRelatedObj(def);
                                            var ftbl = "";
                                            ////////////pf.SaveLog("****** in insrt 19");
                                            try
                                            {
                                                ftbl = defObj.tbls[0];
                                                if (String.IsNullOrWhiteSpace(ftbl))
                                                {
                                                    ftbl = "";
                                                }
                                            }
                                            catch
                                            {
                                                ftbl = "";
                                            }
                                            ////////////pf.SaveLog("****** in insrt 20");
                                            if (!String.IsNullOrWhiteSpace(ftbl))
                                            {
                                                ////////////pf.SaveLog("****** in insrt 21");
                                                //tbl : ftbl , id: d
                                                var tblInfo = aph.getTableInfo(ftbl);

                                                //////pf.SaveLog("** need copy action for table :" + tblInfo.Title + " from rec : " + d);



                                                //=============================================================




                                                var newId2 = "0";
                                                var tblId2 = tblInfo.id;
                                                var rcId2 = d;
                                                //////pf.SaveLog("** need copy 2");
                                                var recsJsn2 = aph.getTableRecordEine(tblId2, sid, pakSid, rcId2);
                                                var unL2 = (new MaxReseller.Funcs.jsonify()).getUnknownList(recsJsn2);
                                                var cuTblRec2 = unL2.First();
                                                //////pf.SaveLog("** need copy 3");
                                                var names2 = "";
                                                var vals2 = "";

                                                foreach (var p in cuTblRec2.props)
                                                {
                                                    names2 += p.Key + "sspp";
                                                    vals2 += p.Value + "sspp";
                                                }
                                                //////pf.SaveLog("** need copy 4");
                                                names2 += "ownerTbl" + "sspp";
                                                names2 += "ownerRec" + "sspp";
                                                names2 += "isSingle" + "sspp";
                                                names2 += "isExist" + "sspp";
                                                names2 += "isNew";// + "sspp";
                                                //////pf.SaveLog("** need copy 5");
                                                vals2 += cuTblRec2.ownerTbl + "sspp";
                                                vals2 += newId + "sspp"; // cuTblRec2.ownerRec + "sspp";
                                                vals2 += cuTblRec2.isSingle + "sspp";
                                                vals2 += cuTblRec2.isExist + "sspp";
                                                vals2 += cuTblRec2.isNew;// + "sspp";

                                                //////pf.SaveLog("** need copy 6");
                                                var fldAr2 = pf.vbsplit(names2, "sspp");
                                                var valAr0 = pf.vbsplit(vals2, "sspp");
                                                var valAr02 = valAr0;

                                                //////pf.SaveLog("** need copy 7");
                                                var tblN2 = tblInfo.Title;

                                                nc = new Dictionary<string, string>();
                                                nc.Add("cmd", "RunQuery");
                                                query = "";
                                                query = "insert into wp_" + tblN2 + " (sid," + fldAr2.ToList().Aggregate((a, b) => a + "," + b) + ") values(";
                                                query += dieAdmin.DieSite.id + ",";
                                                //////pf.SaveLog("** need copy 8 - "+ valAr0.Length);
                                                for (var i2 = 0; i2 <= valAr0.Length - 1; i2++)
                                                {
                                                    var v = valAr0[i2];
                                                    //////pf.SaveLog("** need copy 8 - v=" + v);
                                                    try
                                                    {
                                                        if (v.Contains(","))
                                                        {
                                                            valAr02[i2] = "#sq#" + v + "#sq#";
                                                        }
                                                        else
                                                        {
                                                            var tint = Convert.ToDouble(v);
                                                            valAr02[i2] = v;
                                                        }
                                                    }
                                                    catch
                                                    {
                                                        valAr02[i2] = "#sq#" + v + "#sq#";
                                                    }
                                                }
                                                //////pf.SaveLog("** need copy 9");
                                                query += valAr02.ToList().Aggregate((a, b) => a + "," + b) + ")";
                                                ////pf.cleanLog();
                                                ////////////////pf.SaveLog(DateTime.Now.Ticks + " = " + query);
                                                nc.Add("query", query);
                                                qret = aph.sendForm(nc);
                                                ////////////////pf.SaveLog(qret);
                                                //ViewBag.outp = "ActionDone";
                                                //////pf.SaveLog("** need copy 10");
                                                ////////////////pf.SaveLog("**************************** 1");
                                                var recsJsnLast2 = aph.getTableLastRecord(tblId2, sid, pakSid, 1);
                                                ////////////////pf.SaveLog("**************************** 2");
                                                //////pf.SaveLog("** need copy 11");
                                                var unLLast2 = (new MaxReseller.Funcs.jsonify()).getUnknownList(recsJsnLast2);
                                                //////pf.SaveLog("** need copy 12");
                                                ////////////////pf.SaveLog("**************************** 3");
                                                var lastRC2 = unLLast2.First();
                                                //////pf.SaveLog("** need copy 13");
                                                ////////////////pf.SaveLog("**************************** 4");
                                                newId2 = lastRC2.id;

                                                newTvl.Add(newId2);
                                                //////pf.SaveLog("** need copy 14");

                                                //////pf.SaveLog("new copy query : " + query);
                                                //////pf.SaveLog("new prop rec id : " + newId2);



                                                //================================================================




                                                
                                            }
                                        }

                                        // update rec prop query
                                        nc = new Dictionary<string, string>();
                                        nc.Add("cmd", "RunQuery");
                                        query = "";
                                        query = "update wp_" + tblN + " set ";// sid=" + dieAdmin.DieSite.id + ",";
                                        query += f + "=#sq#" + newTvl.Aggregate((a, b) => a + "," + b) + "#sq#";
                                        query += " where (sid=" + dieAdmin.DieSite.id + ") and (id=" + newId + ")";// and (ownerRec=0)";
                                        //////pf.SaveLog("****** a query : " + query);
                                        nc.Add("query", query);
                                        qret = aph.sendForm(nc);
                                        ////////////pf.SaveLog("****** in insrt 23 = "+qret);

                                    }
                                }
                            }
                        }
                    }


                }
                else
                {
                    ViewBag.outp = "PermissionDenied";
                }
            }
            else
            {
                ViewBag.outp = "PermissionDenied";
            }

        }

//------------------------------------

void saveSeoKeys(string[] rp)
        {
            //pf.cleanLog();
            //////////pf.SaveLog("save seo keys");
            var keys = rp[0].Trim();
            var keyar = pf.vbsplit(keys, "nnpp");
            var dieAdmin = aph.getDieAdmin();
            string sid = dieAdmin.DieAdmin.sid;
            string cdate = DateTime.Now.ToString();

            ViewBag.outp = "ActionDone";

            foreach (var k in keyar)
            {
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                query = "";
                query = "insert into wp_seoKey " + "(sid,dieOrder,dieTitle,dieDate) values(";
                query += dieAdmin.DieSite.id + ",";
                query += "'0','" + k + "','" + cdate + "')";
                query = query.Replace("'", "#sq#");
                nc.Add("query", query);
                ////pf.cleanLog();
                //////////pf.SaveLog("query : " + query);
                try
                {
                    qret = aph.sendForm(nc);
                    //////////pf.SaveLog("qret : " + qret);
                    //ViewBag.outp = "ActionDone";
                }
                catch (Exception ex)
                {
                    var er=pf.SaveErr(ex, "seoKey");
                    //////////pf.SaveLog(er);
                    ViewBag.outp = "ActionFailed";
                }
            }
        }
        void saveSeoMedia(string[] rp)
        {
            var mediaId = rp[0].Trim();
            var mediaUrl = rp[1].Trim();
            var title = rp[2].Trim();

            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoMedia " + "(sid,dieWpid,dieUrl,dieTitle,dieDate) values(";
            query += dieAdmin.DieSite.id + ",";
            query += "'" + mediaId + "','" + mediaUrl + "','" + title + "','" + DateTime.Now.ToString() + "')";
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            ////pf.cleanLog();
            ////////////pf.SaveLog("query : " + query);
            try
            {
                qret = aph.sendForm(nc);
            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoMedia");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }

        }


        void saveHelpSeoTag(string[] rp)
        {


            var id = rp[0].Trim();
            var title = rp[1].Trim();
            var ur = rp[2].Trim();
            var parentCat = rp[3].Trim();
            var mediaId = rp[4].Trim();
            var fkey = rp[5].Trim();


            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoPostTag " + "(sid,dieWpid,dieTitle,dieUrl,dieWpMediaId,dieFcosKey) values(";
            query += dieAdmin.DieSite.id + ",";
            query += "'" + id + "','" + title + "','" + ur + "','" + mediaId + "','" + fkey + "')";
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            ////pf.cleanLog();
            ////////////pf.SaveLog("query : " + query);
            try
            {
                qret = aph.sendForm(nc);

                var recId = "0";
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                var query = "select * from wp_seoPostTag where sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
                nc.Add("query", query);
                //////////////pf.SaveLog("send form");
                var outp = aph.sendForm(nc);

                recId = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.seo.seoProductCat>>(outp)[0].id;



                ViewBag.recId = recId;

            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoPostTag");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }
        void saveProductSeoTag(string[] rp)
        {


            var id = rp[0].Trim();
            var title = rp[1].Trim();
            var ur = rp[2].Trim();
            var parentCat = rp[3].Trim();
            var mediaId = rp[4].Trim();
            var fkey = rp[5].Trim();


            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoProductTag " + "(sid,dieWpid,dieTitle,dieUrl,dieWpMediaId,dieFcosKey) values(";
            query += dieAdmin.DieSite.id + ",";
            query += "'" + id + "','" + title + "','" + ur + "','" + mediaId + "','" + fkey + "')";
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            ////pf.cleanLog();
            ////////////pf.SaveLog("query : " + query);
            try
            {
                qret = aph.sendForm(nc);

                var recId = "0";
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                var query = "select * from wp_seoProductTag where sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
                nc.Add("query", query);
                //////////////pf.SaveLog("send form");
                var outp = aph.sendForm(nc);

                recId = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.seo.seoProductCat>>(outp)[0].id;



                ViewBag.recId = recId;

            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoProductTag");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }




        void saveProductContent(string[] rp)
        {


            var id = rp[0].Trim();
            var title = rp[1].Trim();
            var ur = rp[2].Trim();
            var parentCat = rp[3].Trim();
            var mediaId = rp[4].Trim();
            var fkey = rp[5].Trim();


            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoProduct " + "(";// sid,dieWpid,dieTitle,dieUrl,dieParent,dieWpMediaId,dieFcosKey) values(";

            query += "sid,dieWpid,dieSiteUrl,dieUrl,dieTitle,dieSlug,dieKeysId,dieFcosKey,dieSeoThemId,dieWpMediaId,dieTagsId,dieCatsId,dieMainCat,diePrice1,diePrice2,dieDate,dieUpdate) values(";
            //sid,dieWpid,dieSiteUrl,dieUrl,dieTitle
            query += dieAdmin.DieSite.id + ",'" + id + "','','" + ur + "','" + title + "',";
            //dieSlug,dieKeysId,dieFcosKey,dieSeoThemId,dieWpMediaId
            query += "'','','" + fkey + "','','" + mediaId + "',";
            //dieTagsId,dieCatsId,dieMainCat,diePrice1,diePrice2,dieDate,dieUpdate
            query += "'','','" + parentCat + "','','','" + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "')";



           // query += dieAdmin.DieSite.id + ",";
            //query += "'" + id + "','" + title + "','" + ur + "','" + parentCat + "','" + mediaId + "','" + fkey + "')";
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            //pf.cleanLog();
            //////////pf.SaveLog("query add product : " + query);
            try
            {
                qret = aph.sendForm(nc);

                var recId = "0";
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                var query = "select * from wp_seoProduct where sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
                nc.Add("query", query);
                //////////////pf.SaveLog("send form");
                var outp = aph.sendForm(nc);

                recId = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.seo.seoProductCat>>(outp)[0].id;



                ViewBag.recId = recId;

            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoGroup");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }
        void savePostContent(string[] rp)
        {


            var id = rp[0].Trim();
            var title = rp[1].Trim();
            var ur = rp[2].Trim();
            var parentCat = rp[3].Trim();
            var mediaId = rp[4].Trim();
            var fkey = rp[5].Trim();


            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoPost " + "(sid,dieWpid,dieTitle,dieUrl,dieParent,dieWpMediaId,dieFcosKey) values(";
            query += dieAdmin.DieSite.id + ",";
            query += "'" + id + "','" + title + "','" + ur + "','" + parentCat + "','" + mediaId + "','" + fkey + "')";


            query = "";
            query = "insert into wp_seoPost " + "(";// sid,dieWpid,dieTitle,dieUrl,dieParent,dieWpMediaId,dieFcosKey) values(";

            query += "sid,dieWpid,dieSiteUrl,dieUrl,dieTitle,dieSlug,dieKeysId,dieFcosKey,dieSeoThemId,dieWpMediaId,dieTagsId,dieCatsId,dieMainCat,dieDate,dieUpdate) values(";
            //sid,dieWpid,dieSiteUrl,dieUrl,dieTitle
            query += dieAdmin.DieSite.id + ",'" + id + "','','" + ur + "','" + title + "',";
            //dieSlug,dieKeysId,dieFcosKey,dieSeoThemId,dieWpMediaId
            query += "'','','" + fkey + "','','" + mediaId + "',";
            //dieTagsId,dieCatsId,dieMainCat,dieDate,dieUpdate
            query += "'','','" + parentCat + "','" + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "')";



            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            ////pf.cleanLog();
            ////////////pf.SaveLog("query : " + query);
            try
            {
                qret = aph.sendForm(nc);

                var recId = "0";
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                var query = "select * from wp_seoPost where sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
                nc.Add("query", query);
                //////////////pf.SaveLog("send form");
                var outp = aph.sendForm(nc);

                recId = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.seo.seoProductCat>>(outp)[0].id;



                ViewBag.recId = recId;

            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoGroup");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }





        void saveHelpSeoGroup(string[] rp)
        {


            var id = rp[0].Trim();
            var title = rp[1].Trim();
            var ur = rp[2].Trim();
            var parentCat = rp[3].Trim();
            var mediaId = rp[4].Trim();
            var fkey = rp[5].Trim();


            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoPostCat " + "(sid,dieWpid,dieTitle,dieUrl,dieParent,dieWpMediaId,dieFcosKey) values(";
            query += dieAdmin.DieSite.id + ",";
            query += "'" + id + "','" + title + "','" + ur + "','" + parentCat + "','" + mediaId + "','" + fkey + "')";
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            ////pf.cleanLog();
            ////////////pf.SaveLog("query : " + query);
            try
            {
                qret = aph.sendForm(nc);

                var recId = "0";
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                var query = "select * from wp_seoPostCat where sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
                nc.Add("query", query);
                //////////////pf.SaveLog("send form");
                var outp = aph.sendForm(nc);

                recId = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.seo.seoProductCat>>(outp)[0].id;



                ViewBag.recId = recId;

            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoGroup");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }
        void saveSeoGroup(string[] rp)
        {


            var id = rp[0].Trim();
            var title = rp[1].Trim();
            var ur = rp[2].Trim();
            var parentCat = rp[3].Trim();
            var mediaId = rp[4].Trim();
            var fkey = rp[5].Trim();


            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoProductCat " + "(sid,dieWpid,dieTitle,dieUrl,dieParent,dieWpMediaId,dieFcosKey) values(";
            query += dieAdmin.DieSite.id + ",";
            query += "'" + id + "','" + title + "','" + ur + "','" + parentCat + "','" + mediaId + "','" + fkey + "')";
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);
            ////pf.cleanLog();
            ////////////pf.SaveLog("query : " + query);
            try
            {
                qret = aph.sendForm(nc);

                var recId = "0";
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                var query = "select * from wp_seoProductCat where sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
                nc.Add("query", query);
                //////////////pf.SaveLog("send form");
                var outp = aph.sendForm(nc);

                recId = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.seo.seoProductCat>>(outp)[0].id;



                ViewBag.recId = recId;

            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoGroup");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }
        void saveSeoTree(string[] rp)
        {

            var parentTree = rp[0].Trim();
            var recId = rp[1].Trim();
            var dataTyp = rp[2].Trim();
            var title = rp[3].Trim();
            var ur = rp[4].Trim();
            var publish = rp[5].Trim();
            var mediaUrl = rp[6].Trim();
            var wpid = rp[7].Trim();

            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "insert into wp_seoTree " + "(sid,dieParent,dieRecId,dieTyp,dieTitle,dieUrl,dieIsPublished,dieImg) values(";
            query += dieAdmin.DieSite.id + ",";
            query += parentTree + "," + recId + ",'" + dataTyp + "','" + title + "','" + ur + "','" + publish + "','" + mediaUrl + "')";


            query = "insert into wp_seoTree (sid,wpid,dieParent,dieRecId,dieTyp,dieTitle,dieUrl,dieSiteUrl,dieIsPublished,dieImg) values(";
            query += dieAdmin.DieSite.id + ",";
            query += wpid + ",";
            query += parentTree + ",";
            query += recId + ",";
            query += "#sq#" + dataTyp + "#sq#,";//typ
            query += "#sq#" + title + "#sq#,";//dieTitle
            //query += "#sq#" + pf.js_scape(ur) + "#sq#,";//dieUrl
            query += "#sq#" + (ur) + "#sq#,";//dieUrl
            query += "#sq#" + "" + "#sq#,";//dieSiteUrl
            query += "#sq#" + publish + "#sq#,";//dieIsPublished
            //query += "#sq#" + pf.js_scape(mediaUrl) + "#sq#)";//dieImg
            query += "#sq#" + (mediaUrl) + "#sq#)";//dieImg




          //  //pf.cleanLog();
            ////////////pf.SaveLog("nue query : " + query);
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);

            try
            {
                qret = aph.sendForm(nc);
                //////////pf.SaveLog("qret : " + qret);
            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "seoTree");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }

        void doDelMedFile(string[] rp)
        {

            var id = rp[0].Trim();
            

            var dieAdmin = aph.getDieAdmin();

            string sid = dieAdmin.DieAdmin.sid;

            ViewBag.outp = "ActionDone";

            ////pf.cleanLog();

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            //nc.Add("sid", "0");
            var query = "select * from wp_Midias where ";// sid=" + aph.getDieAdmin().DieAdmin.sid + " order by id desc LIMIT 1";
            query += "(sid=" + dieAdmin.DieSite.id + ") and (id=" + id + ")";
            nc.Add("query", query);
            ////////////pf.SaveLog("query select : " + query);
            //////////////pf.SaveLog("send form");
            var outp = aph.sendForm(nc);
           // //////////pf.SaveLog("outp = " + outp);
            var ur = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.midia>>(outp)[0].Fn;//.props["Fn"];
            ////////////pf.SaveLog("ur : " + ur);
            string BaseHost = System.Configuration.ConfigurationManager.AppSettings["BaseHost"].ToString();
            ////////////pf.SaveLog("BaseHost : " + BaseHost);
            var fnad = BaseHost + dieAdmin.DieSite.id + @"\up\" + ur;
           // //////////pf.SaveLog("fnd : " + fnad);
            try
            {
                System.IO.File.Delete(fnad);
            }
            catch { }

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "";
            query = "delete from wp_Midias where ";// + "(sid,dieParent,dieRecId,dieTyp,dieTitle,dieUrl,dieIsPublished,dieImg) values(";
            query += "(sid="+dieAdmin.DieSite.id + ") and (id="+id+")";
           
            query = query.Replace("'", "#sq#");
            nc.Add("query", query);

           
           // //////////pf.SaveLog(query);

            try
            {
                qret = aph.sendForm(nc);
               // //////////pf.SaveLog("qret : " + qret);
            }
            catch (Exception ex)
            {
                var er = pf.SaveErr(ex, "del media");
                //////////pf.SaveLog(er);
                ViewBag.outp = "ActionFailed";
            }
        }

        public void getLastMid(string[] rp)
        {
            try
            {
                var nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                var query = "select * from wp_mlCommingQue order by id desc LIMIT 1";
                nc.Add("query", query);
                var outp = aph.sendForm(nc);

                var unLLast = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                var lastRC = unLLast.First();
                var newId = lastRC.props["mlid"];
                ViewBag.newId = newId;
            }
            catch
            {
                ViewBag.newId = "0";
            }
        }
        public void saveMailList(string[] rp)
        {
            ////pf.SaveLog("in mail lis...");
            var dtstr = pf.js_unscape(rp[0].Trim());

            ////pf.SaveLog("in mail lis...2");
            var sl = aph.getSitesList();
            ////pf.SaveLog("in mail lis...3");
            var rows = pf.vbsplit(dtstr, "#nd#");
            ////pf.SaveLog("in mail lis...4");
            //for (var i = 0; i <= rows.Length - 1; i++)
            for (var i = (rows.Length - 1); i >=0 ; i--)
            {
                ////pf.SaveLog("in mail lis...5");
                if (!String.IsNullOrEmpty(rows[i].Trim()))
                {
                    ////pf.SaveLog("in mail lis...6");
                    var vals = pf.vbsplit(rows[i].Trim(), "#np#");
                    var id = vals[0].Trim();
                    var subj = vals[1].Trim();
                    var from = vals[2].Trim();
                    var dat = vals[3].Trim();
                    var siz = vals[4].Trim();
                    var attch = vals[5].Trim();
                    var ur = vals[6].Trim();
                    var txt = vals[7].Trim();
                    var to = vals[8].Trim();

                    var this_sid = "0";
                    var this_site = "";

                    ////pf.SaveLog("in mail lis...7");

                    if (to.ToLower().Contains(resell.ToLower()))
                    {
                        ////pf.SaveLog("in mail lis...7 a");
                        var tosub = to.ToLower().Replace("@" + resell.ToLower(), "");
                        ////pf.SaveLog("in mail lis...7 a 1");
                        try
                        {
                            var dieSite = sl.Where(a => a.sub.ToLower() == tosub).First();
                            ////pf.SaveLog("in mail lis...7 a 2");
                            this_sid = dieSite.id;
                            ////pf.SaveLog("in mail lis...7 a 3");
                            this_site = tosub + "." + resell;
                            ////pf.SaveLog("in mail lis...7 a 4");
                        }
                        catch
                        {
                            this_sid = "6";
                            this_site = "maxim.shop";
                        }
                    }
                    else
                    {
                        ////pf.SaveLog("in mail lis...7 b");
                        var todm = pf.vbsplit(to, "@")[1];
                        ////pf.SaveLog("in mail lis...7 b 2");
                        var dieSite = sl.Where(a => a.dm.ToLower() == todm.ToLower()).First();
                        ////pf.SaveLog("in mail lis...7 b 3");
                        this_sid = dieSite.id;
                        ////pf.SaveLog("in mail lis...7 b 4");
                        this_site = dieSite.dm;
                        ////pf.SaveLog("in mail lis...7 b 5");
                    }
                    ////pf.SaveLog("in mail lis...8");
                    ViewBag.outp = "ActionDone";

                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");

                    var q = "insert into wp_mlCommingQue (sid,mlid,mlsubj,mlfrom,mldat,mlsiz,mlattch,mlur,mltxt,mlto,mlsite) value(#sid,#mlid,#mlsubj,#mlfrom,#mldat,#mlsiz,#mlattch,#mlur,#mltxt,#mlto,#mlsite)";
                    q = q.Replace("#sid", this_sid);
                    q = q.Replace("#mlid", "#sq#" + id + "#sq#");
                    q = q.Replace("#mlsubj", "#sq#" + subj + "#sq#");
                    q = q.Replace("#mlfrom", "#sq#" + from + "#sq#");
                    q = q.Replace("#mldat", "#sq#" + dat + "#sq#");
                    q = q.Replace("#mlsiz", "#sq#" + siz + "#sq#");
                    q = q.Replace("#mlattch", "#sq#" + attch + "#sq#");
                    q = q.Replace("#mlur", "#sq#" + pf.js_scape(ur) + "#sq#");
                    q = q.Replace("#mltxt", "#sq#" + pf.js_scape(txt) + "#sq#");
                    q = q.Replace("#mlto", "#sq#" + to + "#sq#");
                    q = q.Replace("#mlsite", "#sq#" + this_site + "#sq#");

                    nc.Add("query", q);

                    //pf.SaveLog("*********************insert mail quesr : " + q);

                    try
                    {
                        qret = aph.sendForm(nc);

                        ////pf.SaveLog("*************** insert mail ok:: " + id);

                        var attchStr = vals[9].Trim();
                        if (!String.IsNullOrEmpty(attchStr))
                        {
                            var attachAr = pf.vbsplit(attchStr, "#ntth#");
                            foreach (var dt in attachAr)
                            {
                                if (!String.IsNullOrEmpty(dt.Trim()))
                                {
                                    var atthFlds = pf.vbsplit(dt.Trim(), "#nr#");

                                    var ath_name = atthFlds[0].Trim();
                                    var ath_typ = atthFlds[1].Trim();
                                    var ath_siz = atthFlds[2].Trim();
                                    var ath_link = atthFlds[3].Trim();
                                    var ath_data = atthFlds[4].Trim();

                                    var q2 = "insert into wp_mlCommingQueAttach (sid,mlid,mlname,mltyp,mlsiz,mllink,mldata) values(#sid,#mlid,#mlname,#mltyp,#mlsiz,#mllink,#mldata)";
                                    q2 = q2.Replace("#sid", this_sid);
                                    q2 = q2.Replace("#mlid", "#sq#" + id + "#sq#");
                                    q2 = q2.Replace("#mlname", "#sq#" + ath_name + "#sq#");
                                    q2 = q2.Replace("#mltyp", "#sq#" + ath_typ + "#sq#");
                                    q2 = q2.Replace("#mlsiz", "#sq#" + ath_siz + "#sq#");
                                    q2 = q2.Replace("#mllink", "#sq#" + pf.js_scape(ath_link) + "#sq#");
                                    q2 = q2.Replace("#mldata", "#sq#" + pf.js_scape(ath_data) + "#sq#");

                                    nc = new Dictionary<string, string>();
                                    nc.Add("cmd", "RunQuery");
                                    nc.Add("query", q2);

                                    try
                                    {
                                        qret = aph.sendForm(nc);

                                        ////pf.SaveLog("*************** insert mail ok:: " + id);
                                    }
                                    catch { }

                                }
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        ViewBag.outp = "ActionFailed";
                        ////pf.SaveLog(pf.SaveErr(ex, "insert mail"));
                    }
                }
            }


        }
        //-----------------------------------
        public void editFileInfo(string[] rp)
        {
            try
            {
                var id = rp[0];
                var Title = rp[1];
                var Descibt = rp[2];



                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");

                var q = "update wp_Midias set Title=#sq#"+ Title + "#sq#,Descibt=#sq#"+ Descibt + "#sq#  where id=" + id;// (sid,mlid,mlsubj,mlfrom,mldat,mlsiz,mlattch,mlur,mltxt,mlto,mlsite) value(#sid,#mlid,#mlsubj,#mlfrom,#mldat,#mlsiz,#mlattch,#mlur,#mltxt,#mlto,#mlsite)";
                
                nc.Add("query", q);


                qret = aph.sendForm(nc);
            }
            catch { }
                      
            


        }

        // GET: Shell
        public ActionResult Index()
        {
            ////pf.cleanLog();

            var rp = (string[])Session["request_params"];

            var cmd = Request["CmdName"];
            ViewBag.outp = "";


            switch (cmd)
            {
                case "getuscommandlist":
                    getuscommandlist(rp);
                    break;
                case "runSetup":
                    runSetup(rp);
                    break;
                case "doAddUser":
                    doAddUser(rp);
                    break;
                case "doAddSite":
                    doAddSite(rp);
                    break;
                case "doLoginResell":
                    doLoginResell(rp);
                    break;
                case "doLoginPanel":
                    doLoginPanel(rp);
                    break;
                case "getTableName":
                    getTableName(rp);
                    break;
                case "getFormName":
                    getFormName(rp);
                    break;
                case "doDeleteFromTbl":
                    doDeleteFromTbl(rp);
                    break;
                case "doInserInTable":
                    doInserInTable(rp);
                    break;
                case "doUpdateTable":
                    doUpdateTable(rp);
                    break;
                case "doCopyInTbl":
                    ////pf.cleanLog();
                    doCopyInTbl(rp);
                    break;
                case "doInserInUser":
                    doInserInUser(rp);
                    break;
                case "doUpdateUser":
                    doUpdateUser(rp);
                    break;
                case "doDeleteFromUser":
                    doDeleteFromUser(rp);
                    break;
                case "doChangePass":
                    doChangePass(rp);
                    break;

                case "saveSeoKeys":
                    saveSeoKeys(rp);
                    break;
                case "saveSeoMedia":
                    saveSeoMedia(rp);
                    break;
                case "saveSeoGroup":
                    saveSeoGroup(rp);
                    break;
                case "saveHelpSeoGroup":
                    saveHelpSeoGroup(rp);
                    break;
                case "saveSeoTree":
                    saveSeoTree(rp);
                    break;
                case "saveHelpSeoTag":
                    saveHelpSeoTag(rp);
                    break;
                case "saveProductSeoTag":
                    saveProductSeoTag(rp);
                    break;
                case "saveProductContent":
                    saveProductContent(rp);
                    break;
                case "savePostContent":
                    savePostContent(rp);
                    break;
                case "doDelMedFile":
                    doDelMedFile(rp);
                    break;
                case "saveMailList":
                    saveMailList(rp);
                    break;
                case "getLastMid":
                    getLastMid(rp);
                    break;
                case "editFileInfo":
                    editFileInfo(rp);
                    break;
            }

            ViewBag.res = "sessionucode=" + Request["sessionucode"] + "&params=" + Request["params"] + "&pid=" + Request["pid"] + "&result1=ok&rsp=";

            return View();
        }

        public string fixRecords0()
        {
            //return fixRecords2();
            var ret = "Nothing";

            var added = 0;
            var faild = 0;

            var unl = (List<MaxReseller.Models.unknown>)Session["unl4up"];

            if (pf.canSeekL<MaxReseller.Models.unknown>(unl) == true)
            {
                var dieAdmin = aph.getDieAdmin();
                var tblN = Session["tblN4up"].ToString();
                ret = "";
                foreach (var r in unl)
                {
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    var flns = r.props.Select(a => a.Key).Aggregate((a, b) => a + "," + b) + ",ownerTbl,ownerRec,isSingle,isExist,isNew";
                    query = "insert into wp_" + tblN + " (sid," + flns + ") values(";
                    query += r.sid + ",";
                    //for (var i = 0; i <= r.props.Count() - 1; i++)
                    var valAr2 = new List<string>();
                    foreach (var p in r.props)
                    {
                        var v = p.Value;
                        try
                        {
                            var tint = Convert.ToDouble(v);
                            if (p.Value.Contains(",") == true)
                            {
                                valAr2.Add("#sq#" + v + "#sq#");
                            }
                            else
                            {
                                if (p.Value.Contains(".") == true)
                                {
                                    valAr2.Add("#sq#" + v + "#sq#");
                                }
                                else
                                {
                                    //fldvals += p.Value + ",";
                                    valAr2.Add(v);
                                }
                            }
                            //valAr2.Add(v);
                        }
                        catch
                        {
                            valAr2.Add("#sq#" + v + "#sq#");
                        }
                    }
                    query += valAr2.ToList().Aggregate((a, b) => a + "," + b) + ",";
                    query += r.ownerTbl + "," + r.ownerRec + "," + r.isSingle + "," + r.isExist + "," + r.isNew + ")";
                    nc.Add("query", query);
                    try
                    {
                        qret = aph.sendForm(nc);
                        added++;
                    }
                    catch
                    {
                        faild++;
                    }
                }
            }

            ret = added + " records ADDED OK.<br>" + faild + " records Faild to Add..";

            return ret;
        }
        public string fixRecords()
        {
            var ret = "Nothing";

            var added = 0;
            var faild = 0;
            var cleaned = 0;

            var unl = (List<MaxReseller.Models.unknown>)Session["unl4up"];
            if (unl.Count() == 0)
            {
                var unltxt = System.IO.File.ReadAllText(Server.MapPath("~/BACK/" + Session["tblN4up"].ToString() + ".bak"));
                unl = (new MaxReseller.Funcs.jsonify()).getUnknownList(unltxt);// Session["unl4up"];
            }
            //ret = Session["unl4up"].ToString() + Environment.NewLine;

            if (pf.canSeekL<MaxReseller.Models.unknown>(unl) == true)
            {
                ret += unl.Count() + Environment.NewLine;
                var maxid = unl.OrderBy(a => a.id).Last().id;
                var nextid = 1;
                var addIds = new List<string>();

                var dieAdmin = aph.getDieAdmin();
                var tblN = Session["tblN4up"].ToString();
                ret = "";
                foreach (var r in unl)
                {
                    while(Convert.ToInt64(r.id) > nextid)
                    {
                        ret += "add " + r.id + Environment.NewLine;
                        addIds.Add(nextid.ToString());
                        nc = new Dictionary<string, string>();
                        nc.Add("cmd", "RunQuery");
                        query = "";
                        var flns2 = r.props.Select(a => a.Key).Aggregate((a, b) => a + "," + b) + ",ownerTbl,ownerRec,isSingle,isExist,isNew";
                        query = "insert into wp_" + tblN + " (sid," + flns2 + ") values(";
                        query += r.sid + ",";
                        //for (var i = 0; i <= r.props.Count() - 1; i++)
                        var valAr22 = new List<string>();
                        foreach (var p in r.props)
                        {
                            var v = p.Value;
                            try
                            {
                                var tint = Convert.ToDouble(v);
                                if (p.Value.Contains(",") == true)
                                {
                                    valAr22.Add("#sq#" + v + "#sq#");
                                }
                                else
                                {
                                    if (p.Value.Contains(".") == true)
                                    {
                                        valAr22.Add("#sq#" + v + "#sq#");
                                    }
                                    else
                                    {
                                        //fldvals += p.Value + ",";
                                        valAr22.Add(v);
                                    }
                                }
                                //valAr2.Add(v);
                            }
                            catch
                            {
                                valAr22.Add("#sq#" + v + "#sq#");
                            }
                        }
                        query += valAr22.ToList().Aggregate((a, b) => a + "," + b) + ",";
                        query += r.ownerTbl + "," + r.ownerRec + "," + r.isSingle + "," + r.isExist + "," + r.isNew + ")";
                        ret += query + Environment.NewLine;
                        nc.Add("query", query);
                        try
                        {
                            qret = aph.sendForm(nc);
                            added++;
                        }
                        catch
                        {
                            faild++;
                        }
                        nextid++;
                    }

                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    var flns = r.props.Select(a => a.Key).Aggregate((a, b) => a + "," + b) + ",ownerTbl,ownerRec,isSingle,isExist,isNew";
                    query = "insert into wp_" + tblN + " (sid," + flns + ") values(";
                    query += r.sid + ",";
                    //for (var i = 0; i <= r.props.Count() - 1; i++)
                    var valAr2 = new List<string>();
                    foreach (var p in r.props)
                    {
                        var v = p.Value;
                        try
                        {
                            var tint = Convert.ToDouble(v);
                            if (p.Value.Contains(",") == true)
                            {
                                valAr2.Add("#sq#" + v + "#sq#");
                            }
                            else
                            {
                                if (p.Value.Contains(".") == true)
                                {
                                    valAr2.Add("#sq#" + v + "#sq#");
                                }
                                else
                                {
                                    //fldvals += p.Value + ",";
                                    valAr2.Add(v);
                                }
                            }
                            //valAr2.Add(v);
                        }
                        catch
                        {
                            valAr2.Add("#sq#" + v + "#sq#");
                        }
                    }
                    query += valAr2.ToList().Aggregate((a, b) => a + "," + b) + ",";
                    query += r.ownerTbl + "," + r.ownerRec + "," + r.isSingle + "," + r.isExist + "," + r.isNew + ")";
                    nc.Add("query", query);
                    ret += "reg q " + Environment.NewLine + query + Environment.NewLine;
                    try
                    {
                        qret = aph.sendForm(nc);
                        added++;
                    }
                    catch
                    {
                        faild++;
                    }
                    nextid++;
                }

                if (addIds.Count() > 0)
                {
                    var idsstrs = addIds.Aggregate((a, b) => a + "," + b);
                    query = "delete from wp_" + tblN + " where id in (" + idsstrs + ")";
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    nc.Add("query", query);
                    ret += "del q" + Environment.NewLine + query + Environment.NewLine;
                    try
                    {
                        qret = aph.sendForm(nc);
                        cleaned = addIds.Count();
                    }
                    catch
                    {
                        //faild++;
                    }
                }

            }

            ret += added + " records ADDED OK.<br>" + faild + " records Faild to Add.. " + cleaned + " records are cleand.";

            return ret;
        }

        public ActionResult Go2WPAdmin()
        {

            return View();
        }
       

    }
}