﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MAXIMPanel.Controllers
{
    public class SEOController : Controller
    {
        // GET: SEO
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult List()
        {
            return View();
        }
        public ActionResult TreeSelector()
        {
            return View();
        }
        public ActionResult Keys()
        {
           
            return View();
            
        }
        public ActionResult MediaList()
        {
            return View();
        }
        public ActionResult Group()
        {
            return View();
        }
        public ActionResult TreeList()
        {
            return View();
        }
        public ActionResult List2()
        {
            return View();
        }
        public ActionResult AddProductGroup()
        {
            ViewBag.prm1 = "AddProductGroup";
            return View();
        }
        public ActionResult AddProductTag()
        {
            ViewBag.prm1 = "AddProductTag";
            return View();
        }
        public ActionResult AddProductContent()
        {
            ViewBag.prm1 = "AddProductContent";
            return View();
        }
        public ActionResult AddPostGroup()
        {
            ViewBag.prm1 = "AddPostGroup";
            return View();
        }
        public ActionResult AddPostTag()
        {
            ViewBag.prm1 = "AddPostTag";
            return View();
        }
        public ActionResult AddPostContent()
        {
            ViewBag.prm1 = "AddPostContent";
            return View();
        }
        public ActionResult Media()
        {
            ViewBag.prm1 = "Media";
            return View();
        }
        public ActionResult Help()
        {
            ViewBag.prm1 = "Help";
            return View();
        }
        public ActionResult FormThem1()
        {
            ViewBag.prm1 = "FormThem1";
            return View();
        }
        public ActionResult FormThem2()
        {
            ViewBag.prm1 = "FormThem2";
            return View();
        }
        public ActionResult Tree()
        {
            ViewBag.prm1 = "SEO Tree";
            return View();
        }
        public ActionResult WPRUN()
        {
            ViewBag.prm1 = "WP Runner";
            return View();
        }
        public ActionResult WPdemin()
        {
            ViewBag.prm1 = "WP Demin JS";
            return View();
        }
        public string XList()
        {
            var aph = new AppHelper();
            var pf = new BST_PublicHelper.PubFuncs();
            var recs = aph.getTableRecordsSimpleAll("mxSeoUrls");
            var outl = new List<MaxReseller.Models.seo.seoX>();

            foreach(var r in recs)
            {
                if (r.props["actif"] != "false")
                {
                    var nc = new MaxReseller.Models.seo.seoX();
                    nc.ur = pf.js_unscape(r.props["dieURLx"].Trim());
                    outl.Add(nc);
                }
            }

            return Newtonsoft.Json.JsonConvert.SerializeObject(outl);
        }

    }
}