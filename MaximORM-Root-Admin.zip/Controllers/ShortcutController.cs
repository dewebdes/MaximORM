﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MAXIMPanel.Controllers
{
    public class ShortcutController : Controller
    {
        // GET: Shortcut
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult shop1()
        {
            return View();
        }
        public ActionResult amlak1()
        {
            return View();
        }
        public ActionResult admin()
        {
            return View();
        }
        public ActionResult ads()
        {
            return View();
        }
        public ActionResult delta()
        {
            return View();
        }
        public ActionResult adsportal()
        {
            return View();
        }
        public ActionResult shop2()
        {
            return View();
        }
        public ActionResult football()
        {
            return View();
        }

        public ActionResult fashionshop()
        {
            return View();
        }
        public ActionResult tiketshop()
        {
            return View();
        }
        public ActionResult transport()
        {
            return View();
        }
        public ActionResult maxResident()
        {
            return View();
        }
        public ActionResult company()
        {
            return View();
        }
        public ActionResult restaurant()
        {
            return View();
        }
        public ActionResult pandorapack()
        {
            return View();
        }
        public ActionResult mxchat()
        {
            return View();
        }
        public ActionResult booking()
        {
            return View();
        }
        public ActionResult mihome()
        {
            return View();
        }
    }
}