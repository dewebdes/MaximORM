﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MAXIMPanel.Controllers
{
    public class DesktopController : Controller
    {
        // GET: Desktop
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Home()
        {
            return View();
        }
        public ActionResult Mobile()
        {
            return View();
        }
        public ActionResult WinManager()
        {
            return View();
        }
        public ActionResult StatusBar()
        {
            return View();
        }
        public ActionResult WPAdmin()
        {
            return View();
        }
    }
}