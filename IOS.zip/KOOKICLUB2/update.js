﻿function checkupdate(str) {
    console.log("hi update");
}