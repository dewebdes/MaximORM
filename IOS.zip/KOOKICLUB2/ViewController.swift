//
//  ViewController.swift
//  KOOKICLUB2
//
//  Created by Online WebDesign on 8/27/18.
//  Copyright © 2018 Online WebDesign. All rights reserved.
//

import UIKit
import WebKit
//let contentController = WKUserContentController()
import SafariServices

class ViewController: UIViewController {

    @IBOutlet weak var openBrowserButton: UIButton!
    @IBOutlet weak var openReaderButton: UIButton!
    
    let contentController = WKUserContentController()
    var webView: WKWebView!
    var myToken = "ns1"
    var urlString = ""
    var lastupdt = "0"
    var offdb = "0"
//    var allShops = [shop]()
    var dllur = ""
    var dllnam = ""
    
    var isregfon = "false"
    //var offdb = new Array();
    var mynumber = ""
    var mydiscod = ""
    var myparent = ""
    var mytoken = ""
    
    var mygender = ""
    var myname = ""
    var myfamily = ""
    var myemail = ""
    var myadr = ""
    var mypass = ""
    
    var myotheradresses = ""
    
    var mycredit = "0"
    
    var myustyp = "customer"
    var myfacs = ""
    
    func saveFullDB(for txt2sav : String){
        self.offdb = txt2sav
        
        let file = "offdb.txt" //this is the file. we will write to and read from it
        
        
        print("============start save file")
        
        
        do {
            // get the documents folder url
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                // create the destination url for the text file to be saved
                let fileURL = documentDirectory.appendingPathComponent(file)
                // define the string/text to be saved
                let text = txt2sav //"Hello World !!!"
                // writing to disk
                try text.write(to: fileURL, atomically: false, encoding: .utf8)
                print("=================saving was successful")
                // any code posterior code goes here
                // reading from disk
                let savedText = try String(contentsOf: fileURL)
                
                //startApp()
                
                print("============savedText:", "")   // "Hello World !!!\n"
            }
        } catch {
            print("===================error:", error)
        }
        
        
        
        
        
        
        
        
        
        
        
        /*
         let text = offdb// "some text" //just a text
         
         if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
         
         let fileURL = dir.appendingPathComponent(file)
         
         //writing
         do {
         try text.write(to: fileURL, atomically: false, encoding: .utf8)
         }
         catch {/* error handling here */}
         
         //reading
         do {
         let text2 = try String(contentsOf: fileURL, encoding: .utf8)
         }
         catch {/* error handling here */}
         }
         
         */
        
        /*
         let str = txt2sav//"Super long string here"
         if let filepath = Bundle.main.path(forResource: "offdb", ofType: "txt", inDirectory: "webapp") {
         do {
         do {
         let url = NSURL(string: filepath)
         
         try str.write(to: url as! URL, atomically: true, encoding: String.Encoding.utf8)
         } catch {
         // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
         }
         } catch {
         // contents could not be loaded
         }
         } else {
         // example.txt not found!
         }
         */
        
    }
    
    func saveLastUpdt(for txt2sav : String){
        let str = txt2sav//"Super long string here"
        
        self.lastupdt = txt2sav
        
        let file = "lastupdate.txt" //this is the file. we will write to and read from it
        
        
        do {
            // get the documents folder url
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                // create the destination url for the text file to be saved
                let fileURL = documentDirectory.appendingPathComponent(file)
                // define the string/text to be saved
                let text = txt2sav //"Hello World !!!"
                // writing to disk
                try text.write(to: fileURL, atomically: false, encoding: .utf8)
                print("=================saving last updt was successful")
                // any code posterior code goes here
                // reading from disk
                let savedText = try String(contentsOf: fileURL)
                lastupdt = txt2sav
                print("============savedText:", txt2sav)   // "Hello World !!!\n"
            }
        } catch {
            print("===================error:", error)
        }
        
        
        
        
        
        /*
         let text = str// "some text" //just a text
         
         if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
         
         let fileURL = dir.appendingPathComponent(file)
         
         //writing
         do {
         try text.write(to: fileURL, atomically: false, encoding: .utf8)
         }
         catch {/* error handling here */}
         
         //reading
         do {
         let text2 = try String(contentsOf: fileURL, encoding: .utf8)
         }
         catch {/* error handling here */}
         }
         
         */
        
        
        /*
         if let filepath = Bundle.main.path(forResource: "lastupdate", ofType: "txt", inDirectory: "webapp") {
         do {
         do {
         let url = NSURL(string: filepath)
         
         try str.write(to: url as! URL, atomically: true, encoding: String.Encoding.utf8)
         } catch {
         // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
         }
         } catch {
         // contents could not be loaded
         }
         } else {
         // example.txt not found!
         }
         */
        
        
    }
    
    func loadDBinRam (){
        
        let file2 = "offdb.txt" //this is the file. we will write to and read from it
        
        //let text = "some text" //just a text
        
        
        do {
            
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                
                let fileURL = documentDirectory.appendingPathComponent(file2)
               
                let savedText = try String(contentsOf: fileURL)
                self.offdb = savedText
                
                //startApp()
                
            }
        } catch {
            print("===================error:", error)
        }
        
    }
    func getNewDB (){
        let urlbs = URL(string: "http://transport.maxim.shop/OffLine/getoffdb")
        
        let task = URLSession.shared.dataTask(with: urlbs!) { (data, response, error) in
            
            if let data = data {
                do {
                    var backToString = String(data: data, encoding: String.Encoding.utf8) as String!
                    
                    //print("++++bak2string is: " + backToString!)
                    var lines: [String] = []
                    backToString?.enumerateLines { line, _ in
                        lines.append(line)
                    }
                    
                     print("*** off db is line0: "+lines[0])
                    print("*** line1: "+lines[1])
                    
                    self.saveFullDB(for: backToString!)
                    self.saveLastUpdt(for: lines[0])
                  //  self.loadDBinRam()
                    self.offdb = backToString!
                    
                }  catch let error as NSError {
                    print(error.localizedDescription)
                }
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
        
        task.resume()
        
    }
    
    
    func setDevToken(for deviceTokenString : String)
    {
        myToken = deviceTokenString
        /*webView.evaluateJavaScript("setDeviceIdent('" + deviceTokenString + "')") { (result, error) in
         if error != nil {
         //print(result)
         }
         }*/
        mytoken = myToken
    }
    
    func updatepersons(){
        
        
        let file = "peronalin.txt"
        
        var defperson = "var isregfon = " + isregfon + "';"
       // defperson = defperson + " var offdb = new Array();"
        defperson = defperson + " var mynumber = '" + mynumber + "';"
        defperson = defperson + " var mydiscod = '" + mydiscod + "';"
        defperson = defperson + " var myparent = '" + myparent + "';"
        defperson = defperson + " var mytoken = '" + myToken + "';"
        
        defperson = defperson + " var mygender = '" + mygender + "';"
        defperson = defperson + " var myname = '" + myname + "';"
        defperson = defperson + " var myfamily = '" + myfamily + "';"
        defperson = defperson + " var myemail = '" + myemail + "';"
        defperson = defperson + " var myadr = '" + myadr + "';"
        defperson = defperson + " var mypass = '" + mypass + "';"
        
        defperson = defperson + " var myotheradresses = '" + myotheradresses + "';"
        
        defperson = defperson + " var mycredit = '" + mycredit + "';"
        
        defperson = defperson + " var myustyp = '" + myustyp + "';"
        defperson = defperson + " var myfacs = '" + myfacs + "';"
        
        
        var cudefperson = ""
        do {
            // get the documents folder url
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                // create the destination url for the text file to be saved
                let fileURL = documentDirectory.appendingPathComponent(file)
                
               
                
                
                // define the string/text to be saved
                //   let text = offdb //"Hello World !!!"
                // writing to disk
                //try text.write(to: fileURL, atomically: false, encoding: .utf8)
                //print("=================saving was successful")
                // any code posterior code goes here
                // reading from disk
                let savedText = try String(contentsOf: fileURL)
                cudefperson = savedText
                //print("============savedText off :", self.lastupdt)   // "Hello World !!!\n"
            }
        } catch {
            cudefperson = ""
            print("===================error:", error)
        }
        
        print("***person:: " + cudefperson)
        
        if (cudefperson == "") {
            
            print("****write : " + defperson)
            
            do {
                
                if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                    
                    let fileURL = documentDirectory.appendingPathComponent(file)
                    
                    
                    try defperson.write(to: fileURL, atomically: false, encoding: .utf8)
                    print("===personals==============saving was successful")
                    }
            } catch {
                }
            
        }else{
            
            
            print("** not null")
            
            let fullNameArr = cudefperson.components(separatedBy: "';")
            
            isregfon = fullNameArr[0].replacingOccurrences(of: "var isregfon = ", with: "")

            print("***** isregfon:: " + isregfon)
            
          //  defperson = defperson + " var offdb = new Array();"
            mynumber = fullNameArr[1].replacingOccurrences(of: " var mynumber = '", with: "")
            mydiscod = fullNameArr[2].replacingOccurrences(of: " var mydiscod = '" , with: "")
            myparent = fullNameArr[3].replacingOccurrences(of: " var myparent = '", with: "")
           // mytoken = fullNameArr[4].replacingOccurrences(of: " var mytoken = '", with: "")
            
            mygender = fullNameArr[5].replacingOccurrences(of: " var mygender = '", with: "")
            myname = fullNameArr[6].replacingOccurrences(of: " var myname = '", with: "")
            myfamily = fullNameArr[7].replacingOccurrences(of: " var myfamily = '", with: "")
            myemail = fullNameArr[8].replacingOccurrences(of: " var myemail = '", with: "")
            myadr = fullNameArr[9].replacingOccurrences(of: " var myadr = '", with: "")
            mypass = fullNameArr[10].replacingOccurrences(of: " var mypass = '", with: "")
            
            myotheradresses = fullNameArr[11].replacingOccurrences(of: " var myotheradresses = '", with: "")
            
            mycredit = fullNameArr[12].replacingOccurrences(of: " var mycredit = '", with: "")
            
            myustyp = fullNameArr[13].replacingOccurrences(of: " var myustyp = '", with: "")
            myfacs = fullNameArr[14].replacingOccurrences(of: " var myfacs = '", with: "")
            
        }
        
    }
    
    
    func savepersons(){
        
        
        let file = "peronalin.txt"
        
        var defperson = "var isregfon = " + isregfon + "';"
        // defperson = defperson + " var offdb = new Array();"
        defperson = defperson + " var mynumber = '" + mynumber + "';"
        defperson = defperson + " var mydiscod = '" + mydiscod + "';"
        defperson = defperson + " var myparent = '" + myparent + "';"
        defperson = defperson + " var mytoken = '" + myToken + "';"
        
        defperson = defperson + " var mygender = '" + mygender + "';"
        defperson = defperson + " var myname = '" + myname + "';"
        defperson = defperson + " var myfamily = '" + myfamily + "';"
        defperson = defperson + " var myemail = '" + myemail + "';"
        defperson = defperson + " var myadr = '" + myadr + "';"
        defperson = defperson + " var mypass = '" + mypass + "';"
        
        defperson = defperson + " var myotheradresses = '" + myotheradresses + "';"
        
        defperson = defperson + " var mycredit = '" + mycredit + "';"
        
        defperson = defperson + " var myustyp = '" + myustyp + "';"
        defperson = defperson + " var myfacs = '" + myfacs + "';"
        
        
     //   var cudefperson = ""
        do {
            // get the documents folder url
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                // create the destination url for the text file to be saved
                let fileURL = documentDirectory.appendingPathComponent(file)
                
                
                
                
                // define the string/text to be saved
                //   let text = offdb //"Hello World !!!"
                // writing to disk
                try defperson.write(to: fileURL, atomically: false, encoding: .utf8)
                //print("=================saving was successful")
                // any code posterior code goes here
                // reading from disk
               // let savedText = try String(contentsOf: fileURL)
               // cudefperson = savedText
                //print("============savedText off :", self.lastupdt)   // "Hello World !!!\n"
            }
        } catch {
         //   cudefperson = ""
            print("===================error:", error)
        }
        
      
        
    }
    
    func startApp(for tpg : String){
        var scriptSource = ""
        
        var lines: [String] = []
        print("&&&&&&&& db: " + self.offdb)
        self.offdb.enumerateLines { line, _ in
            scriptSource = scriptSource + "offdb[offdb.length] = '" + (line) + "';"
        }
        
        // let file0 = "peronalin.txt"
        
        var defperson = "var isregfon = " + isregfon + ";"
        defperson = defperson + " offdb = new Array();"
        defperson = defperson + " var mynumber = '" + mynumber + "';"
        defperson = defperson + " var mydiscod = '" + mydiscod + "';"
        defperson = defperson + " var myparent = '" + myparent + "';"
        defperson = defperson + " var mytoken = '" + mytoken + "';"
        
        defperson = defperson + " var mygender = '" + mygender + "';"
        defperson = defperson + " var myname = '" + myname + "';"
        defperson = defperson + " var myfamily = '" + myfamily + "';"
        defperson = defperson + " var myemail = '" + myemail + "';"
        defperson = defperson + " var myadr = '" + myadr + "';"
        defperson = defperson + " var mypass = '" + mypass + "';"
        
        defperson = defperson + " var myotheradresses = '" + myotheradresses + "';"
        
        defperson = defperson + " var mycredit = '" + mycredit + "';"
        
        defperson = defperson + " var myustyp = '" + myustyp + "';"
        defperson = defperson + " var myfacs = '" + myfacs + "';"
        
        scriptSource = defperson + scriptSource
        
        let script = WKUserScript(source: scriptSource, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        contentController.addUserScript(script)
        
        let config = WKWebViewConfiguration()
        //let userContentController = WKUserContentController()
        
        contentController.add(self as! WKScriptMessageHandler, name: "myApp")
        
        //config.userContentController = userContentController
        config.userContentController = contentController
        //self.view.scrollView.bounces = false
        webView = WKWebView(frame: .zero, configuration: config)
        
        view.addSubview(webView)
        webView.isHidden = true
        /*
         guard let scriptPath = Bundle.main.path(forResource: "script", ofType: "js"),
         let scriptSource = try? String(contentsOfFile: scriptPath) else { return }
         
         let userScript = WKUserScript(source: scriptSource, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
         userContentController.addUserScript(userScript)
         */
        
        let layoutGuide = view.safeAreaLayoutGuide
        
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.leadingAnchor.constraint(equalTo: layoutGuide.leadingAnchor).isActive = true
        webView.trailingAnchor.constraint(equalTo: layoutGuide.trailingAnchor).isActive = true
        webView.topAnchor.constraint(equalTo: layoutGuide.topAnchor).isActive = true
        webView.bottomAnchor.constraint(equalTo: layoutGuide.bottomAnchor).isActive = true
        
        // if let url = URL(string: "https://www.google.com") {
        //   webView.load(URLRequest(url: url))
        //}
        let url = Bundle.main.url(forResource: tpg, withExtension: "html")!
        webView.load(URLRequest(url:url))
        
    }
    
    //var logo: UIImageView!
    @IBOutlet var logox: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
        //let imageName = "iTunesArtwork@1x.png"
        //let image = UIImage(named: imageName)
        //logo = UIImageView(image: image!)
        //logo.contentMode = .scaleAspectFit //.center// .scaleAspectFit
        
        //view.addSubview(logo)
        
        UIView.animate(withDuration: 4.0, delay: 0.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.logox.alpha = 0.0
            self.logox.transform = CGAffineTransform(scaleX: 2, y: 2);
        }, completion: {
            (finished: Bool) -> Void in
            
            self.webView.isHidden = false
            
        })
        
        
        
        self.updatepersons()
        
      
        let file = "lastupdate.txt" //this is the file. we will write to and read from it
        
        
        
        
        do {
            // get the documents folder url
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                // create the destination url for the text file to be saved
                let fileURL = documentDirectory.appendingPathComponent(file)
                // define the string/text to be saved
                //   let text = offdb //"Hello World !!!"
                // writing to disk
                //   try text.write(to: fileURL, atomically: false, encoding: .utf8)
                //print("=================saving was successful")
                // any code posterior code goes here
                // reading from disk
                let savedText = try String(contentsOf: fileURL)
                self.lastupdt = savedText
                print("============savedText off :", self.lastupdt)   // "Hello World !!!\n"
            }
        } catch {
            print("===================error:", error)
        }
        
        
        let file2 = "offdb.txt" //this is the file. we will write to and read from it
        
        //let text = "some text" //just a text
        
        
        do {
            // get the documents folder url
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                // create the destination url for the text file to be saved
                let fileURL = documentDirectory.appendingPathComponent(file2)
                // define the string/text to be saved
                //let text = offdb //"Hello World !!!"
                // writing to disk
                //try text.write(to: fileURL, atomically: false, encoding: .utf8)
                //print("=================saving was successful")
                // any code posterior code goes here
                // reading from disk
                let savedText = try String(contentsOf: fileURL)
                self.offdb = savedText
                //print("============savedText off :", "")   // "Hello World !!!\n"
            }
        } catch {
            print("===================error:", error)
        }
        
        
        //self.offdb = self.offdb.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //self.lastupdt = self.lastupdt.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        
        let isLastUpdateNull = ((self.lastupdt == "") || (self.lastupdt == "0"))
        let isLastDBNull = ((self.offdb == "") || (self.offdb == "0"))
        let need2update = (isLastUpdateNull && isLastDBNull)
        
        if(need2update == true){
            print("&&&&& yes go 2 update")
            self.getNewDB()
            
        }
        
        print("---*****---------self.lastupdt: "+self.lastupdt)
        
        print("----******--------self.offdb: "+self.offdb)
        
        
        if(need2update == false){
            
            
            if(isLastDBNull == false){
            //    self.loadDBinRam()
            }
            
            
            
            let urlbs = URL(string: "http://transport.maxim.shop/OffLine/need2update?upd="+self.lastupdt)
            
            let task = URLSession.shared.dataTask(with: urlbs!) { (data, response, error) in
                
                if let data = data {
                    do {
                        var backToString = String(data: data, encoding: String.Encoding.utf8) as String!
                        
                        if(backToString == "y"){
                            self.getNewDB()
                        }else{
                            self.loadDBinRam()
                        }
                        
                    }  catch let error as NSError {
                        self.loadDBinRam()
                        print(error.localizedDescription)
                    }
                } else if let error = error {
                    self.loadDBinRam()
                    print(error.localizedDescription)
                }
            }
            
            task.resume()
            
            
        }
        
        
        if(offdb.count<100){
            startApp(for: "00") //000
        }else{
            startApp(for: "00")
        }
       
       // webView.scrollView.bounces = NO

    }
    
    
    func removeSwipeGesture(){
       // self.view.accessibilityScroll(false)
        for view in self.view.subviews {
            if let subView = view as? UIScrollView {
                subView.isScrollEnabled = false
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


extension ViewController: SFSafariViewControllerDelegate {
    func safariViewController(_ controller: SFSafariViewController, didCompleteInitialLoad didLoadSuccessfully: Bool) {
        //Tells the delegate that the initial URL load completed.
    }
    
    func safariViewController(_ controller: SFSafariViewController, activityItemsFor URL: URL, title: String?) -> [UIActivity] {
        //Tells the delegate that the user tapped an Action button.
        return []
    }
    
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        //Tells the delegate that the user dismissed the view.
    }
}


extension ViewController: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "myApp", let messageBody = message.body as? String {
            print(messageBody)
            
            let fullNameArr = messageBody.components(separatedBy: "#np#")
            
            let cmd    = fullNameArr[0]
            //
            
            if cmd == "callajax" {
                
                let prm1 = fullNameArr[1]
                callajax3(ur: prm1)
                
            }
            if cmd == "callajax4" {
                
                let prm1 = fullNameArr[1]
                callajax4(ur: prm1)
                
            }
            
            if cmd == "tobase64" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                //tobase64(ur: prm1)
                
            }
            if cmd == "savemyotheradres" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                myotheradresses = myotheradresses + "nnpp" + prm1
                savepersons()
            }
            if cmd == "add2credit" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
               // let prm1 = fullNameArr?[1]
                let dieUr:String? = prm1
                urlString = dieUr!
                openBrowser(withReaderMode: false)
                
            }
            if cmd == "openaparat" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                // let prm1 = fullNameArr?[1]
                let dieUr:String? = prm1
                urlString = dieUr!
                openBrowser(withReaderMode: false)
                
            }
            if cmd == "openinsta" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                // let prm1 = fullNameArr?[1]
                let dieUr:String? = prm1
                urlString = dieUr!
                openBrowser(withReaderMode: false)
                
            }
            if cmd == "dopaysaman" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                
                //let prm1 = fullNameArr?[1]
                let dieUr:String? = "http://maxim.shop/pay/kookisaman.php?fid=" + prm1
                
                urlString = dieUr!
                openBrowser(withReaderMode: false)
                
            }
            if cmd == "dopaymelat" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                
                //let prm1 = fullNameArr?[1]
                let dieUr:String? = "http://maxim.shop/pay/kookimelat.php?fid=" + prm1
                
                urlString = dieUr!
                openBrowser(withReaderMode: false)
                
            }
            if cmd == "savecredit" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                mycredit = prm1
                savepersons()
            }
            if cmd == "saveprofo" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                mynumber = prm1
                isregfon = "true"
                savepersons()
            }
            
            if cmd == "savedisco" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                mydiscod = prm1
                savepersons()
            }
            if cmd == "savemyparent" {
                
                let prm1 = fullNameArr[1]
                //callajax4(ur: prm1)
                myparent = prm1
            }
            if cmd == "savePersonals" {
                //mygender + "#np#" + myname + "#np#" + myfamily + "#np#" + myemail + "#np#" + myadr + "#np#" + mypass
                mygender = fullNameArr[1]
                //callajax4(ur: prm1)
                myname = fullNameArr[2]
                myfamily = fullNameArr[3]
                myemail = fullNameArr[4]
                myadr = fullNameArr[5]
                mypass = fullNameArr[6]
                savepersons()
                
            }
            
            
          /*  if let url = URL(string: "javascript:filter('www')") {
               webView.load(URLRequest(url: url))
            }*/
            
            //filterTowns(filter: "red")
        }
    }
    
    func tobase64(ur: String){
        let urlbs = URL(string: "http://transport.maxim.shop/kookiclub/getbase64img")
        
        //let urlprms = ur.components(separatedBy: "?")
        //let reqprms = urlprms[1].components(separatedBy: "formdatax=")
        //let cmdprm = urlprms[1].components(separatedBy: "&")
        //let cmdprm2 = cmdprm[0].components(separatedBy: "=")
        
        
        
        //self.saveFullDB(for: <#T##String#>)
        
        
        
        let url = URL(string: "http://transport.maxim.shop/KookiKlub/tobase64img")!
        var request = URLRequest(url: url)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        let postString = "imgn="+ur //+"&formdatax="+reqprms[1]
        request.httpBody = postString.data(using: .utf8)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {                                                 // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            var responseString = String(data: data, encoding: .utf8)
          //  print("responseString = \(responseString)")
            
            let aString = self.offdb // "This is my string"
            let newString = aString.replacingOccurrences(of: ur, with: responseString!)
            
            self.saveFullDB(for: newString)
            
        }
        task.resume()
        
        
        
        
        
        
        
        
        
        
    }
    
    
    fileprivate func openBrowser(withReaderMode readerMode: Bool) {
        let svc = SFSafariViewController(url: NSURL(string: self.urlString)! as URL, entersReaderIfAvailable: readerMode)
        // You can also init the view controller with the SFSafariViewController:url: method
        svc.delegate = self
        if #available(iOS 10.0, *) {
            // The color to tint the background of the navigation bar and the toolbar.
            svc.preferredBarTintColor = readerMode ? .blue : .orange
            // The color to tint the the control buttons on the navigation bar and the toolbar.
            svc.preferredControlTintColor = .white
        } else {
            // Fallback on earlier versions
        }
        present(svc, animated: true, completion: nil)
    }
    
    @IBAction func openInAppBrowser(_ sender: UIButton) {
        openBrowser(withReaderMode: false)
    }
    
    @IBAction func openReaderMode(_ sender: UIButton) {
        openBrowser(withReaderMode: true)
    }
    
    func callajax3(ur: String){
        let urlbs = URL(string: ur)
        
        let urlprms = ur.components(separatedBy: "?")
        let reqprms = urlprms[1].components(separatedBy: "formdatax=")
        let cmdprm = urlprms[1].components(separatedBy: "&")
        let cmdprm2 = cmdprm[0].components(separatedBy: "=")
        
        
        
        
        
        
        
        let url = URL(string: urlprms[0])!
        var request = URLRequest(url: url)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        let postString = "CmdName="+cmdprm2[1]+"&formdatax="+reqprms[1]
        request.httpBody = postString.data(using: .utf8)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {                                                 // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
            
            let js = "ajax3fin(\""+responseString!+"\");"
            print("jscall:: "+js)
            DispatchQueue.main.async{
            self.webView.evaluateJavaScript(js) { (count, error) in
                if let error = error {
                    // self.processJSError(error)
                    print("err occured js:")
                    print(error)
                    return
                }
                
                DispatchQueue.main.async {
                    if let count = count as? Int {
                        //  self.countLabel.text = "\(count) town(s)"
                    } else {
                        //self.countLabel.text = ""
                    }
                }
            }
            }
            
        }
        task.resume()
        
        
        
        
        
        
        
        
        
      
    }
    
    func callajax4(ur: String){
        let urlbs = URL(string: ur)
        
        let urlprms = ur.components(separatedBy: "?")
        //let reqprms = urlprms[1].components(separatedBy: "formdatax=")
        //let cmdprm = urlprms[1].components(separatedBy: "&")
        //let cmdprm2 = cmdprm[0].components(separatedBy: "=")
        
        
        
        
        
        
        
        let url = URL(string: urlprms[0])!
        var request = URLRequest(url: url)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        let postString = urlprms[1]// "CmdName="+cmdprm2[1]+"&formdatax="+reqprms[1]
        request.httpBody = postString.data(using: .utf8)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {                                                 // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
            let trimmed = responseString?.replacingOccurrences(of: "\n\r", with: "")
            let trimmed2 = trimmed?.replacingOccurrences(of: "\n", with: "")
            let trimmed3 = trimmed2?.replacingOccurrences(of: "\r", with: "")

            let js = "ajax4fin('"+trimmed3!+"');"
            print("jscall:: "+js)
            DispatchQueue.main.async{
                self.webView.evaluateJavaScript(js) { (count, error) in
                    if let error = error {
                        // self.processJSError(error)
                        print("err occured js:")
                        print(error)
                        return
                    }
                    
                    DispatchQueue.main.async {
                        if let count = count as? Int {
                            //  self.countLabel.text = "\(count) town(s)"
                        } else {
                            //self.countLabel.text = ""
                        }
                    }
                }
            }
            
        }
        task.resume()
        
        
        
        
        
        
        
        
        
        
    }
    
    
    func filterTowns(filter: String) {
        print("start filter")
        let js = "filter(\"\(filter)\");"
        webView.evaluateJavaScript(js) { (count, error) in
            if let error = error {
               // self.processJSError(error)
                print("err occured 22")
                print(error)
                return
            }
            
            DispatchQueue.main.async {
                if let count = count as? Int {
                  //  self.countLabel.text = "\(count) town(s)"
                } else {
                    //self.countLabel.text = ""
                }
            }
        }
    }
}


