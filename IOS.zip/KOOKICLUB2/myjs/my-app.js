﻿var $$ = Dom7;
Framework7.use(Framework73dPanels);

//var app = new Framework7({
//    root: '#app',

//});

var app = new Framework7({
    // App root element
    root: '#app',
    // App Name
    name: 'kookiclub',
    // App id
    id: 'com.myapp.test',

    
    picker: {
        rotateEffect: true,
        openIn: 'sheet',
        toolbar:false,
        cols: [{
            textAlign: 'center',
            values: ['20000', '40000', '60000', '80000', '100000']
        }, ],
        inputEl: '#picker-money',
    },
    // Add default routes
    routes: [
        {
            path: '/00/',
            pageName: '00',
        },
        {
            path: '/01/',
            pageName: '01',
        },
        {
            path: '/02/',
            pageName: '02',
        },
        {
            path: '/03/',
            pageName: '03',
        },
        {
            path: '/01b/',
            pageName: '01b',
        },
        {
            path: '/04/',
            pageName: '04',
        },
        {
            path: '/05/',
            pageName: '05',
        },
        {
            path: '/06/',
            pageName: '06',
        },
        {
            path: '/06b/',
            pageName: '06b',
        },
        {
            path: '/07/',
            pageName: '07',
        },
        {
            path: '/08/',
            pageName: '08',
        },
        {
            path: '/08b/',
            pageName: '08b',
        },
        {
            path: '/08c/',
            pageName: '08c',
        },
        {
            path: '/08d/',
            pageName: '08d',
        },
        {
            path: '/09/',
            pageName: '09',
        },
        {
            path: '/10/',
            pageName: '10',
        },
        {
            path: '/11/',
            pageName: '11',
        },
        {
            path: '/12/',
            pageName: '12',
        },
        {
            path: '/13/',
            pageName: '13',
        }
    
    
    ],
    
    // ... other parameters
});

var mainView = app.views.create('.view-main', {
    stackPages: true, iosSwipeBack: false
});
// slider
console.log('swip2 a');
var err_adres = app.dialog.create({
    text: 'آدرس کامل وارد نمایید',
    buttons: [
      {
          text: 'باشه',
      }],
});


//جستجو
//tooltip
function showTooltip() {
    $('.tltip').removeClass('displayno');
    //alert(0);
}