var $$ = Dom7;
Framework7.use(Framework73dPanels);

//var app = new Framework7({
//    root: '#app',

//});
var app = new Framework7({
    // App root element
    root: '#app',
    // App Name
    name: 'kookiclub',
    // App id
    id: 'com.myapp.test',

    panel: {
        swipe: 'both',
    },
    panels3d: {
        enabled: true,
    },
    picker: {
        rotateEffect: true,
        openIn: 'sheet',
        toolbar:false,
        cols: [{
            textAlign: 'center',
            values: ['2000', '3000', '4000', '5000', '6000', '7000', '8000', '9000']
        }, ],
        inputEl: '#picker-money',
    },
    
    // Add default routes
    routes: [
        {
            path: '/p1/',
            pageName: 'page1',
            on: {pageAfterIn: function (e, page) {}}
        },
    {
        path: '/p2/',
        pageName: 'page2',
        on: {
            pageAfterIn: function (e, page) {
                $('.rate_widget a').click(function () {
                    // make sure the chosen star stays selected
                    var star = $(this);
                    star.closest('ul').find('.checked').removeClass('checked');
                    star.addClass('checked');

                    //whatever else you want to do when something gets clicked
                });

            }
        },

    },
    {
        path: '/p3/',
        pageName: 'page3',
        on: {
            pageAfterIn: function (event, page) {
                //var idp = page.route.params.id;
                var stepper = app.stepper.create({
                    el: '.stepper',
                    min: 1,
                });
            },
        }
    },
     {
         path: '/p4/',
         pageName: 'page4',
         on: { pageAfterIn: function (e, page) { } }
     },
     {
         path: '/p5/',
         pageName: 'page5',
         on: { pageAfterIn: function (e, page) { } }
     },
     {
         path: '/p6/',
         pageName: 'page6',
         on: { pageAfterIn: function (e, page) { } }
     },
    
    ],
    clicks: {
        "externalLinks": ".external"
},
    // ... other parameters
});

var mainView = app.views.create('.view-main', {
    stackPages: true
    //url: '/',
    //pushState: true,
});
// slider
var mySwiper = new Swiper('.per1 .swiper-container', {
    autoplay: {
        delay: 5000,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    pagination: {
        el: '.swiper-pagination',
        type: 'bullets',
        clickable:true,
    },
});
var mySwiper4 = new Swiper('.swiper-4', {
    pagination: '.swiper-4 .swiper-pagination',
    lazyLoading: true,
    spaceBetween: 20,
    slidesPerView: 2
});

function setprd(id) {
    switch (id) {
        case 1:
            $("#img3").attr('src', 'img/Angel_cake_slice.jpg');
            $("#name3").html('Angel cake');
            $("#mony3").html('82$');
            $('.ad2b').attr('idp', '1');
            break;
        case 2:
            $("#img3").attr('src', 'img/Angel_food.jpg');
            $("#name3").html('Angel food cake');
            $("#mony3").html('74$');
            $('.ad2b').attr('idp', '2');
            break;
        case 3:
            $("#img3").attr('src', 'img/babka.jpg');
            $("#name3").html('Babka');
            $("#mony3").html('67$');
            $('.ad2b').attr('idp', '3');
            break;
        case 4:
            $("#img3").attr('src', 'img/Chiffon_cake.jpg');
            $("#name3").html('Chiffon cake');
            $("#mony3").html('91$');
            $('.ad2b').attr('idp', '4');
            break;


        case 5:
            $("#img3").attr('src', 'img/Hollandse_appeltaart.jpg');
            $("#name3").html('Apple cake');
            $("#mony3").html('86$');
            $('.ad2b').attr('idp', '5');
            break;
        case 6:
            $("#img3").attr('src', 'img/Applesauce_cake.jpg');
            $("#name3").html('Applesauce cake');
            $("#mony3").html('76$');
            $('.ad2b').attr('idp', '6');
            break;
        case 7:
            $("#img3").attr('src', 'img/Aranygaluska.jpg');
            $("#name3").html('Aranygaluska');
            $("#mony3").html('63$');
            $('.ad2b').attr('idp', '7');
            break;
        case 8:
            $("#img3").attr('src', 'img/Blackout_cake.jpg');
            $("#name3").html('Blackout cake');
            $("#mony3").html('94$');
            $('.ad2b').attr('idp', '8');
            break;
    }
}

function add2c(ip, numb) {
    var vl = parseInt($(".badge").html());
    //alert(ip); alert(numb);
    $(".badge").html(vl + 1);
    //clickCounter();
    var nam = ""; var prc = ""; var src = "";
    switch (ip) {
        case '1':
            nam = "Angel cake";
            prc = parseInt(numb) * 82;
            src = "img/Angel_cake_slice.jpg";
            break;
        case '2':
            nam = "Angel food cake";
            prc = parseInt(numb) * 74;
            src = "img/Angel_food.jpg";
            break;
        case '3':
            nam = "Babka";
            prc = parseInt(numb) * 67;
            src = "img/babka.jpg";
            
            break;
        case '4':
            nam = "Chiffon cake";
            prc = parseInt(numb) * 91;
            src = "img/Chiffon_cake.jpg";

            break;

        case '5':
            nam = "Apple cake";
            prc = parseInt(numb) * 86;
            src = "img/Hollandse_appeltaart.jpg";
            break;
        case '6':
            nam = "Applesauce cake";
            prc = parseInt(numb) * 76;
            src = "img/Applesauce_cake.jpg";
            break;
        case '7':
            nam = "Aranygaluska";
            prc = parseInt(numb) * 63;
            src = "img/Aranygaluska.jpg";

            break;
        case '8':
            nam = "Blackout cake";
            prc = parseInt(numb) * 94;
            src = "img/Blackout_cake.jpg";

            break;
    }
    $('.bsket_viw').append('<li class="flex-row  margBtm"><div class="img-blk"><img src="' + src + '" />' +
                            '</div><div class="txt-blk txt-ltr"><label>' + nam + '</label>' +
                                '<p class="flex-column"><span>Number: ' + numb + '</span>' +
                                '<span class="pric">' + prc + ' $</span></p></div></li>');
}

$('#RegN').on('click', function () {
    var username = $('.popup-sign [name="regUs"]').val();
    var password = $('.popup-sign [name="regPs"]').val();
    if (((username == 'Test1')) || ((username == '') && (password == ''))) {
        app.dialog.alert('Error! Please Check Form');
    } else {
        $("#usReg").val(username);
        $("#psReg").val(password);
        app.dialog.alert('Register Succeed');
        app.popup.close('.popup-sign');

    }


});

$('.popup-login .login-button').on('click', function () {
    var us = $('.popup-login [name="username"]').val();
    var pass = $('.popup-login [name="password"]').val();

    var us1 = $('#usReg').val();
    var ps1 = $('#psReg').val();
    if ((((us == 'Test1') && (pass == '1234')) || ((us == us1) && (pass == ps1))) && (us.length > 1)) {
        app.dialog.alert('Welcome Dear ' + us);
        app.popup.close('.popup-login');
        $("body").addClass("islogin");
    } else {
        app.dialog.alert('Username And Password unCorrect!');
    }

});


$('.fnlbsk').on('click', function () {
    //app.panel.close("right", true);
    var totv = 0;
    $('.popup-cart').find('.pric').each(function () {
        
        var p = $(this).text().split("$");
        totv += parseInt(p[0]);
        //alert(p[0]);
        // This is your rel value
    });

    if ($("body").hasClass("islogin")) {
        app.dialog.alert("Your payment is: $" + totv);
        $('.faktorid').text(totv * 456 + 'kclb');
        $('.fnprc').text(totv + ' $');
        app.popup.close('.popup-cart');
        mainView.router.navigate('/p4/');
        //app.routes.navigation("/p4/");
    } else {
        app.popup.open('.popup-login');
    }
});

$('.acht .paybtn').on('click', function () {
    var pay = $('.payInf').val();
    if (pay == '') {
        app.dialog.alert('Please Send Your Payment Info!');
    }
    else {
        app.dialog.alert('Your Request Is Under Process.');
        //reload();
    }
});


setInterval(function () {
    if ($("body").hasClass("islogin")) {
        $('.islog').html("Hi " + $("#usReg").val());
    }
}, 2000);

$('.send_cnt').on('click', function () {
    var username = $('.neun [name="mail"]').val();
    var password = $('.neun [name="pm"]').val();
    if ((username !== "") && (password !== "")) {
        app.dialog.alert('Send Successs');
        $('.neun [name="mail"]').val('');
       $('.neun [name="pm"]').val('');
    } else {
        app.dialog.alert('Please Fill All Fild!');
    }
});
