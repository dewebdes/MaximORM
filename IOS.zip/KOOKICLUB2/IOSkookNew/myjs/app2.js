﻿var $$ = Dom7;
Framework7.use(Framework73dPanels);

//var app = new Framework7({
//    root: '#app',

//});
var app = new Framework7({
    // App root element
    root: '#app',
    // App Name
    name: 'kookiclub',
    // App id
    id: 'com.myapp.test',

    panel: {
        swipe: 'both',
    },
    panels3d: {
        enabled: true,
    },
    picker: {
        rotateEffect: true,
        openIn: 'sheet',
        toolbar: false,
        cols: [{
            textAlign: 'center',
            values: ['2000', '3000', '4000', '5000', '6000', '7000', '8000', '9000']
        }, ],
        inputEl: '#picker-money',
    },
    // Add default routes
    routes: [
        {
            path: '/p1/',
            pageName: 'page1',
            on: { pageAfterIn: function (e, page) { } }
        },
    {
        path: '/p2/',
        pageName: 'page2',
    },
    {
        path: '/zwei/',
        url: './02.html',
    },
    {
        path: '/drei/',
        url: './03.html',
        on: {
            pageAfterIn: function (e, page) {
                $('.rate_widget a').click(function () {
                    // make sure the chosen star stays selected
                    var star = $(this);
                    star.closest('ul').find('.checked').removeClass('checked');
                    star.addClass('checked');

                    //whatever else you want to do when something gets clicked
                });

            }
        },
    },
    {
        path: '/vier/',
        url: './04.html',
        on: {
            pageAfterIn: function (e, page) {

                $(".qntbtn").click(function () {
                    //alert(9);
                    var $button = $(this);
                    var oldValue = $button.parent().find("input").val();
                    //alert(oldValue);
                    if ($button.attr("dt") == "up") {
                        var newVal = parseFloat(oldValue) + 1;
                    } else {
                        // Don"t allow decrementing below zero
                        if (oldValue > 1) {
                            var newVal = parseFloat(oldValue) - 1;
                        } else {
                            newVal = 1;
                        }
                    }
                    $button.parent().find("input").val(newVal);
                });
                //

            }
        }
    },
    {
        path: '/funf/',
        url: '05.html',
        on: {
            pageAfterIn: function (e, page) {

                $(".qntbtn").click(function () {
                    //alert(9);
                    var $button = $(this);
                    var oldValue = $button.parent().find("input").val();
                    //alert(oldValue);
                    if ($button.attr("dt") == "up") {
                        var newVal = parseFloat(oldValue) + 1;
                    } else {
                        // Don"t allow decrementing below zero
                        if (oldValue > 1) {
                            var newVal = parseFloat(oldValue) - 1;
                        } else {
                            newVal = 1;
                        }
                    }
                    $button.parent().find("input").val(newVal);
                });
                //

            }
        }
    },
    {
        path: '/sechs/',
        url: '06.html',
    },
    {
        path: '/sieben/',
        url: '07.html',
        on: {
            pageAfterIn: function (e, page) { }
        }
    },
    {
        path: '/acht/',
        url: '08.html',
        on: {
            pageAfterIn: function (e, page) { }
        }
    },
    {
        path: '/neun/',
        url: '09.html',
        on: {
            pageAfterIn: function (e, page) { }
        }
    },
    {
        path: '/zehn/',
        url: '10.html',
        on: {
            pageAfterIn: function (e, page) { }
        }
    },
    {
        path: '/elf/',
        url: '11.html',
        on: {
            pageAfterIn: function (e, page) {
                app.picker.create();
            }
        }
    },
    ],

    // ... other parameters
    views: {
        stackPages: true
    }
});

var mainView = app.views.create('.view-main', {
    //url: '/',
    //pushState: true,
});
// slider
var mySwiper = new Swiper('.swiper-container', {
    autoplay: {
        delay: 5000,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    pagination: {
        el: '.swiper-pagination',
        type: 'bullets',
        clickable: true,
    },
});
var err_adres = app.dialog.create({
    text: 'آدرس کامل وارد نمایید',
    buttons: [
      {
          text: 'باشه',
      }],
});
function plusAdd() {
    var adr = $('#newAdd').val();
    if (adr.length > 5) {
        $('<li class="margBtm flex-row-rev"><p class="txt-rtl rtl"><span>آدرس:</span>' + adr + '</p><label class="item-radio item-content"><input type="radio" name="adrs" value=""><i class="icon icon-radio"></i></label></li>').
        insertBefore('.add_adres ul>li:last');
        $('#newAdd').val('');
    } else {
        err_adres.open()
    }
}

//جستجو
var fruits = ('Apple Apricot Avocado Banana Melon Orange Peach Pear Pineapple').split(' ');
var autocompleteDropdownSimple = app.autocomplete.create({
    inputEl: '#autocomplete-dropdown',
    openIn: 'dropdown',
    source: function (query, render) {
        var results = [];
        if (query.length === 0) {
            render(results);
            return;
        }
        // Find matched items
        for (var i = 0; i < fruits.length; i++) {
            if (fruits[i].toLowerCase().indexOf(query.toLowerCase()) >= 0) results.push(fruits[i]);
        }
        // Render items by passing array with result items
        render(results);
    }
});
//tooltip
function showTooltip() {
    $('.tltip').removeClass('displayno');
    //alert(0);
}